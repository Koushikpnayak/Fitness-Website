import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User } from '@/lib/data';
import { 
  initializeData, 
  getSession, 
  setSession, 
  clearSession, 
  getUserById, 
  getUserByEmail, 
  saveUser, 
  hashPassword,
  deleteUser as deleteUserFromStorage
} from '@/lib/storage';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signup: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  updateUser: (updates: Partial<User>) => void;
  deleteAccount: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Initialize seed data
    initializeData();
    
    // Check for existing session
    const session = getSession();
    if (session) {
      const existingUser = getUserById(session.userId);
      if (existingUser) {
        setUser(existingUser);
      }
    }
    setLoading(false);
  }, []);

  // Apply theme to document
  useEffect(() => {
    const theme = user?.settings?.theme || 'dark';
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [user?.settings?.theme]);

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    setLoading(true);
    
    // Simulate network delay for UX
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const existingUser = getUserByEmail(email);
    if (!existingUser) {
      setLoading(false);
      return { success: false, error: 'User not found. Please sign up first.' };
    }
    
    const passwordHash = await hashPassword(password);
    if (existingUser.passwordHash !== passwordHash) {
      setLoading(false);
      return { success: false, error: 'Incorrect password. Please try again.' };
    }
    
    setSession(existingUser.id);
    setUser(existingUser);
    setLoading(false);
    return { success: true };
  };

  const signup = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    setLoading(true);
    
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const existingUser = getUserByEmail(email);
    if (existingUser) {
      setLoading(false);
      return { success: false, error: 'An account with this email already exists.' };
    }
    
    const passwordHash = await hashPassword(password);
    const newUser: User = {
      id: `user-${Date.now()}`,
      email,
      passwordHash,
      name: '',
      age: 0,
      height: 0,
      weight: 0,
      goal: '',
      level: '',
      diet: '',
      cuisine: '',
      allergies: [],
      isAdmin: false,
      onboardingComplete: false,
      settings: {
        theme: 'dark',
        glassMl: 250,
        dailyWaterGoal: 8,
      },
      waterLogs: {},
      workoutLogs: [],
      mealOverrides: {},
      createdAt: new Date().toISOString(),
    };
    
    saveUser(newUser);
    setSession(newUser.id);
    setUser(newUser);
    setLoading(false);
    return { success: true };
  };

  const logout = () => {
    clearSession();
    setUser(null);
  };

  const updateUser = (updates: Partial<User>) => {
    if (!user) return;
    
    const updatedUser = { ...user, ...updates };
    saveUser(updatedUser);
    setUser(updatedUser);
  };

  const deleteAccount = () => {
    if (!user) return;
    deleteUserFromStorage(user.id);
    clearSession();
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, signup, logout, updateUser, deleteAccount }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
