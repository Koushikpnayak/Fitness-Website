import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { User, Exercise, Food, Feedback } from '@/lib/data';
import { 
  getUsers, getExercises, saveExercise, deleteExercise,
  getFoods, saveFood, deleteFood, getFeedback, saveFeedback,
  getChatMessages, deleteChatMessage, exportAllData, importAllData
} from '@/lib/storage';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/hooks/use-toast';
import {
  Users, Dumbbell, Utensils, MessageSquare, Star,
  Plus, Trash2, Edit, Download, Upload, Check, X, Save
} from 'lucide-react';

export function AdminPanel() {
  const { user } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [foods, setFoods] = useState<Food[]>([]);
  const [feedbackList, setFeedbackList] = useState<Feedback[]>([]);
  const [chatMessages, setChatMessages] = useState<any[]>([]);
  const [editingExercise, setEditingExercise] = useState<Exercise | null>(null);
  const [newExercise, setNewExercise] = useState<Partial<Exercise>>({});
  const [showAddExercise, setShowAddExercise] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setUsers(getUsers());
    setExercises(getExercises());
    setFoods(getFoods());
    setFeedbackList(getFeedback());
    setChatMessages(getChatMessages());
  };

  const handleExportData = () => {
    const data = exportAllData();
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nutrifit-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: 'Data exported!' });
  };

  const handleImportData = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (importAllData(result)) {
        loadData();
        toast({ title: 'Data imported successfully!' });
      } else {
        toast({ title: 'Import failed', variant: 'destructive' });
      }
    };
    reader.readAsText(file);
  };

  const handleSaveExercise = (exercise: Exercise) => {
    saveExercise(exercise);
    setExercises(getExercises());
    setEditingExercise(null);
    toast({ title: 'Exercise saved!' });
  };

  const handleDeleteExercise = (id: string) => {
    if (confirm('Delete this exercise?')) {
      deleteExercise(id);
      setExercises(getExercises());
      toast({ title: 'Exercise deleted' });
    }
  };

  const handleAddExercise = () => {
    if (!newExercise.name) return;

    const exercise: Exercise = {
      id: `e-${Date.now()}`,
      name: newExercise.name || '',
      category: (newExercise.category as any) || 'strength',
      description: newExercise.description || '',
      defaultSets: newExercise.defaultSets || 3,
      defaultReps: newExercise.defaultReps || 10,
      videos: newExercise.videos || [],
      tags: newExercise.tags || [],
      difficulty: (newExercise.difficulty as any) || 'beginner',
      muscleGroups: newExercise.muscleGroups || [],
      goalFit: newExercise.goalFit || [],
    };

    saveExercise(exercise);
    setExercises(getExercises());
    setNewExercise({});
    setShowAddExercise(false);
    toast({ title: 'Exercise added!' });
  };

  const handleDeleteChat = (id: string) => {
    deleteChatMessage(id);
    setChatMessages(getChatMessages());
    toast({ title: 'Message deleted' });
  };

  const handleMarkFeedbackAddressed = (feedback: Feedback) => {
    saveFeedback({ ...feedback, addressed: true });
    setFeedbackList(getFeedback());
    toast({ title: 'Marked as addressed' });
  };

  if (!user?.isAdmin) {
    return <div>Access denied</div>;
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-heading font-bold">Admin Panel</h1>
          <p className="text-muted-foreground mt-1">Manage app data and users</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleExportData}>
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <label>
            <Button variant="outline" asChild>
              <span>
                <Upload className="w-4 h-4 mr-2" />
                Import
              </span>
            </Button>
            <input
              type="file"
              accept=".json"
              onChange={handleImportData}
              className="hidden"
            />
          </label>
        </div>
      </div>

      <Tabs defaultValue="users">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="users" className="gap-2">
            <Users className="w-4 h-4" />
            Users
          </TabsTrigger>
          <TabsTrigger value="exercises" className="gap-2">
            <Dumbbell className="w-4 h-4" />
            Exercises
          </TabsTrigger>
          <TabsTrigger value="foods" className="gap-2">
            <Utensils className="w-4 h-4" />
            Foods
          </TabsTrigger>
          <TabsTrigger value="chat" className="gap-2">
            <MessageSquare className="w-4 h-4" />
            Chat
          </TabsTrigger>
          <TabsTrigger value="feedback" className="gap-2">
            <Star className="w-4 h-4" />
            Feedback
          </TabsTrigger>
        </TabsList>

        {/* Users Tab */}
        <TabsContent value="users" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Registered Users ({users.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {users.map((u) => (
                  <div key={u.id} className="flex items-center justify-between p-4 rounded-xl bg-secondary/50">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center font-bold text-primary">
                        {u.name?.[0] || u.email[0]}
                      </div>
                      <div>
                        <p className="font-medium">{u.name || 'No name'}</p>
                        <p className="text-sm text-muted-foreground">{u.email}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {u.isAdmin && <Badge>Admin</Badge>}
                      <Badge variant="outline" className="capitalize">{u.goal || 'No goal'}</Badge>
                      <Badge variant="outline" className="capitalize">{u.level || 'No level'}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Exercises Tab */}
        <TabsContent value="exercises" className="mt-6 space-y-4">
          <div className="flex justify-end">
            <Button onClick={() => setShowAddExercise(true)} className="gradient-primary">
              <Plus className="w-4 h-4 mr-2" />
              Add Exercise
            </Button>
          </div>

          {showAddExercise && (
            <Card>
              <CardHeader>
                <CardTitle>Add New Exercise</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Name</Label>
                    <Input
                      value={newExercise.name || ''}
                      onChange={(e) => setNewExercise({ ...newExercise, name: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label>Category</Label>
                    <select
                      className="w-full h-10 px-3 rounded-md border border-input bg-background"
                      value={newExercise.category || 'strength'}
                      onChange={(e) => setNewExercise({ ...newExercise, category: e.target.value as any })}
                    >
                      <option value="strength">Strength</option>
                      <option value="cardio">Cardio</option>
                      <option value="flexibility">Flexibility</option>
                      <option value="hiit">HIIT</option>
                    </select>
                  </div>
                </div>
                <div>
                  <Label>Description</Label>
                  <Textarea
                    value={newExercise.description || ''}
                    onChange={(e) => setNewExercise({ ...newExercise, description: e.target.value })}
                  />
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label>Default Sets</Label>
                    <Input
                      type="number"
                      value={newExercise.defaultSets || 3}
                      onChange={(e) => setNewExercise({ ...newExercise, defaultSets: parseInt(e.target.value) })}
                    />
                  </div>
                  <div>
                    <Label>Default Reps</Label>
                    <Input
                      type="number"
                      value={newExercise.defaultReps || 10}
                      onChange={(e) => setNewExercise({ ...newExercise, defaultReps: parseInt(e.target.value) })}
                    />
                  </div>
                  <div>
                    <Label>Difficulty</Label>
                    <select
                      className="w-full h-10 px-3 rounded-md border border-input bg-background"
                      value={newExercise.difficulty || 'beginner'}
                      onChange={(e) => setNewExercise({ ...newExercise, difficulty: e.target.value as any })}
                    >
                      <option value="beginner">Beginner</option>
                      <option value="intermediate">Intermediate</option>
                      <option value="advanced">Advanced</option>
                    </select>
                  </div>
                </div>
                <div>
                  <Label>Video URLs (comma separated)</Label>
                  <Input
                    placeholder="https://youtube.com/embed/..., https://youtube.com/embed/..."
                    value={newExercise.videos?.join(', ') || ''}
                    onChange={(e) => setNewExercise({ 
                      ...newExercise, 
                      videos: e.target.value.split(',').map(v => v.trim()).filter(Boolean) 
                    })}
                  />
                </div>
                <div className="flex gap-2">
                  <Button onClick={handleAddExercise} className="gradient-primary">
                    <Save className="w-4 h-4 mr-2" />
                    Save
                  </Button>
                  <Button variant="outline" onClick={() => setShowAddExercise(false)}>
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle>Exercises ({exercises.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {exercises.map((ex) => (
                  <div key={ex.id} className="flex items-center justify-between p-4 rounded-xl bg-secondary/50">
                    <div>
                      <p className="font-medium">{ex.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {ex.category} • {ex.difficulty} • {ex.defaultSets}×{ex.defaultReps}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="ghost" size="icon" onClick={() => setEditingExercise(ex)}>
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleDeleteExercise(ex.id)}>
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Foods Tab */}
        <TabsContent value="foods" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Food Database ({foods.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {foods.map((food) => (
                  <div key={food.id} className="flex items-center justify-between p-4 rounded-xl bg-secondary/50">
                    <div>
                      <p className="font-medium">{food.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {food.cuisine} • {food.veg ? 'Veg' : 'Non-Veg'} • {food.caloriesPer100g} kcal/100g
                      </p>
                    </div>
                    <div className="flex gap-2">
                      {food.allergens.length > 0 && (
                        <Badge variant="outline">{food.allergens.length} allergens</Badge>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Chat Tab */}
        <TabsContent value="chat" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Chat Messages ({chatMessages.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {chatMessages.slice(0, 20).map((msg) => (
                  <div key={msg.id} className="flex items-start justify-between p-4 rounded-xl bg-secondary/50">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{msg.username}</p>
                        <Badge variant="outline" className="capitalize">{msg.type}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{msg.text}</p>
                      <p className="text-xs text-muted-foreground mt-2">
                        {new Date(msg.timestamp).toLocaleString()}
                      </p>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => handleDeleteChat(msg.id)}>
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Feedback Tab */}
        <TabsContent value="feedback" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>User Feedback ({feedbackList.length})</CardTitle>
            </CardHeader>
            <CardContent>
              {feedbackList.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">No feedback yet</p>
              ) : (
                <div className="space-y-3">
                  {feedbackList.map((fb) => (
                    <div key={fb.id} className="p-4 rounded-xl bg-secondary/50">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="font-medium">{fb.title}</p>
                          <p className="text-sm text-muted-foreground">{fb.username}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="flex">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star
                                key={i}
                                className={`w-4 h-4 ${i < fb.rating ? 'fill-yellow-500 text-yellow-500' : 'text-muted'}`}
                              />
                            ))}
                          </div>
                          {fb.addressed ? (
                            <Badge className="bg-success text-success-foreground">Addressed</Badge>
                          ) : (
                            <Button size="sm" onClick={() => handleMarkFeedbackAddressed(fb)}>
                              <Check className="w-4 h-4 mr-1" />
                              Mark Done
                            </Button>
                          )}
                        </div>
                      </div>
                      <p className="mt-2 text-sm">{fb.message}</p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
