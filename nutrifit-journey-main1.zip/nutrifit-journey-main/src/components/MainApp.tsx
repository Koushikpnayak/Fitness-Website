import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { generateMealPlan, DailyMealPlan, recalculateMealItem } from '@/lib/nutrition';
import { generateWorkoutPlan, getTodayWorkout, WeeklyWorkoutPlan, DailyWorkoutPlan } from '@/lib/workouts';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Checkbox } from '@/components/ui/checkbox';
import { CommunityTab } from '@/components/CommunityTab';
import { AdminPanel } from '@/components/AdminPanel';
import { SettingsPanel } from '@/components/SettingsPanel';
import { toast } from '@/hooks/use-toast';
import { 
  Home, Utensils, Dumbbell, Droplets, Users, Settings, 
  LogOut, Flame, Target, TrendingUp, Clock, Plus, Minus, 
  Play, Shield, X
} from 'lucide-react';

type TabType = 'dashboard' | 'nutrition' | 'workouts' | 'water' | 'community' | 'settings' | 'admin';

export function MainApp() {
  const { user, logout, updateUser } = useAuth();
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [mealPlan, setMealPlan] = useState<DailyMealPlan | null>(null);
  const [workoutPlan, setWorkoutPlan] = useState<WeeklyWorkoutPlan | null>(null);
  const [todayWorkout, setTodayWorkout] = useState<DailyWorkoutPlan | null>(null);

  useEffect(() => {
    if (user) {
      setMealPlan(generateMealPlan(user));
      const wp = generateWorkoutPlan(user);
      setWorkoutPlan(wp);
      setTodayWorkout(getTodayWorkout(wp));
    }
  }, [user]);

  const getTodayDate = () => new Date().toISOString().split('T')[0];
  const getWaterCount = () => user?.waterLogs[getTodayDate()] || 0;

  const addWater = () => {
    if (!user) return;
    const newLogs = { ...user.waterLogs, [getTodayDate()]: getWaterCount() + 1 };
    updateUser({ waterLogs: newLogs });
    toast({ title: 'Water logged! 💧' });
  };

  const removeWater = () => {
    if (!user) return;
    const current = getWaterCount();
    if (current > 0) {
      updateUser({ waterLogs: { ...user.waterLogs, [getTodayDate()]: current - 1 } });
    }
  };

  const waterProgress = user ? (getWaterCount() / user.settings.dailyWaterGoal) * 100 : 0;

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'nutrition', label: 'Nutrition', icon: Utensils },
    { id: 'workouts', label: 'Workouts', icon: Dumbbell },
    { id: 'water', label: 'Water', icon: Droplets },
    { id: 'community', label: 'Community', icon: Users },
    { id: 'settings', label: 'Settings', icon: Settings },
    ...(user?.isAdmin ? [{ id: 'admin', label: 'Admin', icon: Shield }] : []),
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardTab user={user!} mealPlan={mealPlan} todayWorkout={todayWorkout} waterProgress={waterProgress} waterCount={getWaterCount()} />;
      case 'nutrition':
        return <NutritionTab mealPlan={mealPlan} setMealPlan={setMealPlan} />;
      case 'workouts':
        return <WorkoutsTab workoutPlan={workoutPlan} todayWorkout={todayWorkout} />;
      case 'water':
        return <WaterTab user={user!} waterCount={getWaterCount()} waterProgress={waterProgress} addWater={addWater} removeWater={removeWater} />;
      case 'community':
        return <CommunityTab />;
      case 'settings':
        return <SettingsPanel />;
      case 'admin':
        return user?.isAdmin ? <AdminPanel /> : null;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen flex bg-background">
      {/* Sidebar - Desktop */}
      <aside className="hidden lg:flex flex-col w-64 border-r border-border bg-card/50">
        <div className="p-6 border-b border-border">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl gradient-primary">
              <Dumbbell className="w-6 h-6 text-primary-foreground" />
            </div>
            <span className="text-xl font-heading font-bold">NutriFit</span>
          </div>
        </div>
        
        <nav className="flex-1 p-4 space-y-2">
          {navItems.map((item) => (
            <button key={item.id} onClick={() => setActiveTab(item.id as TabType)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                activeTab === item.id ? 'bg-primary text-primary-foreground shadow-glow' : 'hover:bg-secondary text-muted-foreground hover:text-foreground'
              }`}>
              <item.icon className="w-5 h-5" />
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-border">
          <div className="p-4 rounded-xl bg-secondary/50 mb-4">
            <p className="font-medium truncate">{user?.name || 'User'}</p>
            <p className="text-sm text-muted-foreground truncate">{user?.email}</p>
          </div>
          <Button variant="ghost" onClick={logout} className="w-full justify-start text-muted-foreground hover:text-destructive">
            <LogOut className="w-5 h-5 mr-3" />Sign Out
          </Button>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 flex flex-col">
        <header className="lg:hidden flex items-center justify-between p-4 border-b border-border bg-card/50">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg gradient-primary"><Dumbbell className="w-5 h-5 text-primary-foreground" /></div>
            <span className="font-heading font-bold">NutriFit</span>
          </div>
          <Button variant="ghost" size="icon" onClick={logout}><LogOut className="w-5 h-5" /></Button>
        </header>

        <div className="flex-1 overflow-y-auto p-4 lg:p-8 pb-24 lg:pb-8">{renderContent()}</div>

        <nav className="lg:hidden fixed bottom-0 left-0 right-0 flex justify-around p-2 bg-card/95 backdrop-blur-lg border-t border-border">
          {navItems.slice(0, 5).map((item) => (
            <button key={item.id} onClick={() => setActiveTab(item.id as TabType)}
              className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-all ${activeTab === item.id ? 'text-primary' : 'text-muted-foreground'}`}>
              <item.icon className="w-5 h-5" />
              <span className="text-[10px] font-medium">{item.label}</span>
            </button>
          ))}
        </nav>
      </main>
    </div>
  );
}

// Dashboard, Nutrition, Workouts, Water tabs (simplified for brevity)
function DashboardTab({ user, mealPlan, todayWorkout, waterProgress, waterCount }: any) {
  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const today = dayNames[new Date().getDay()];

  return (
    <div className="space-y-6 animate-fade-in">
      <div><h1 className="text-3xl font-heading font-bold">Hello, {user.name?.split(' ')[0] || 'there'}! 👋</h1><p className="text-muted-foreground mt-1">Let's crush your goals today</p></div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { icon: Flame, value: mealPlan?.totals.calories || 0, label: 'Calories target', color: 'bg-accent/10', iconColor: 'text-accent' },
          { icon: Target, value: `${mealPlan?.totals.protein || 0}g`, label: 'Protein target', color: 'bg-primary/10', iconColor: 'text-primary' },
          { icon: Droplets, value: `${waterCount}/${user.settings.dailyWaterGoal}`, label: 'Glasses water', color: 'bg-blue-500/10', iconColor: 'text-blue-500' },
          { icon: TrendingUp, value: user.goal?.split(' ')[0] || 'Health', label: 'Your goal', color: 'bg-success/10', iconColor: 'text-success' },
        ].map((stat, i) => (
          <Card key={i} className="card-hover"><CardContent className="p-4"><div className="flex items-center gap-3"><div className={`p-2 rounded-lg ${stat.color}`}><stat.icon className={`w-5 h-5 ${stat.iconColor}`} /></div><div><p className="text-2xl font-bold">{stat.value}</p><p className="text-xs text-muted-foreground">{stat.label}</p></div></div></CardContent></Card>
        ))}
      </div>
      <Card><CardHeader className="pb-3"><CardTitle className="flex items-center gap-2"><Dumbbell className="w-5 h-5 text-primary" />Today's Workout - {today}</CardTitle></CardHeader>
        <CardContent>{todayWorkout?.exercises?.length > 0 ? (<div className="space-y-3"><div className="flex items-center justify-between p-3 rounded-xl bg-primary/10"><div><p className="font-semibold">{todayWorkout.focus}</p><p className="text-sm text-muted-foreground">{todayWorkout.exercises.length} exercises • ~{todayWorkout.totalDuration} min</p></div><div className="flex items-center gap-2 text-sm text-muted-foreground"><Clock className="w-4 h-4" />{todayWorkout.scheduledTime}</div></div></div>) : (<div className="text-center py-8 text-muted-foreground"><p className="text-lg">🧘 Rest Day</p></div>)}</CardContent></Card>
      <Card><CardHeader className="pb-3"><CardTitle className="flex items-center gap-2"><Droplets className="w-5 h-5 text-blue-500" />Water Intake</CardTitle></CardHeader><CardContent><Progress value={Math.min(waterProgress, 100)} className="h-3" /><div className="flex justify-between text-sm mt-2"><span className="text-muted-foreground">{waterCount} glasses</span><span className="text-muted-foreground">{Math.round(waterProgress)}% of goal</span></div></CardContent></Card>
    </div>
  );
}

function NutritionTab({ mealPlan, setMealPlan }: any) {
  const updatePortion = (mealType: string, index: number, newGrams: number) => {
    if (!mealPlan) return;
    const updatedMeals = { ...mealPlan.meals };
    updatedMeals[mealType][index] = recalculateMealItem(updatedMeals[mealType][index], newGrams);
    const totals = { calories: 0, protein: 0, carbs: 0, fat: 0 };
    Object.values(updatedMeals).flat().forEach((item: any) => { totals.calories += item.calories; totals.protein += item.protein; totals.carbs += item.carbs; totals.fat += item.fat; });
    setMealPlan({ ...mealPlan, meals: updatedMeals, totals: { calories: Math.round(totals.calories), protein: Math.round(totals.protein), carbs: Math.round(totals.carbs), fat: Math.round(totals.fat) } });
  };
  if (!mealPlan) return null;
  const mealEmojis: any = { breakfast: '🌅', lunch: '☀️', dinner: '🌙', snacks: '🍎' };
  return (
    <div className="space-y-6 animate-fade-in">
      <div><h1 className="text-3xl font-heading font-bold">Meal Plan</h1><p className="text-muted-foreground mt-1">Personalized nutrition for your goals</p></div>
      <Card className="gradient-primary text-primary-foreground"><CardContent className="p-6"><div className="grid grid-cols-4 gap-4 text-center">{[{ v: mealPlan.totals.calories, l: 'Calories' }, { v: `${mealPlan.totals.protein}g`, l: 'Protein' }, { v: `${mealPlan.totals.carbs}g`, l: 'Carbs' }, { v: `${mealPlan.totals.fat}g`, l: 'Fat' }].map((s, i) => (<div key={i}><p className="text-3xl font-bold">{s.v}</p><p className="text-sm opacity-80">{s.l}</p></div>))}</div></CardContent></Card>
      {(['breakfast', 'lunch', 'dinner', 'snacks'] as const).map((mealType) => (
        <Card key={mealType}><CardHeader className="pb-3"><CardTitle className="flex items-center gap-2 capitalize"><span className="text-xl">{mealEmojis[mealType]}</span>{mealType}</CardTitle></CardHeader>
          <CardContent className="space-y-3">{mealPlan.meals[mealType].map((item: any, index: number) => (<div key={index} className="p-4 rounded-xl bg-secondary/50 space-y-3"><div className="flex items-center justify-between"><div><p className="font-semibold">{item.food.name}</p>{item.replaced && <p className="text-xs text-accent">{item.replacementReason}</p>}</div><div className="flex items-center gap-2"><button onClick={() => updatePortion(mealType, index, Math.max(25, item.grams - 25))} className="p-1 rounded-lg bg-secondary hover:bg-secondary/80"><Minus className="w-4 h-4" /></button><span className="w-16 text-center font-medium">{item.grams}g</span><button onClick={() => updatePortion(mealType, index, item.grams + 25)} className="p-1 rounded-lg bg-secondary hover:bg-secondary/80"><Plus className="w-4 h-4" /></button></div></div><div className="flex gap-4 text-sm text-muted-foreground"><span>{item.calories} cal</span><span>{item.protein}g protein</span></div></div>))}</CardContent></Card>
      ))}
    </div>
  );
}

function WorkoutsTab({ workoutPlan, todayWorkout }: any) {
  const [selectedDay, setSelectedDay] = useState<string | null>(null);
  const [playingVideo, setPlayingVideo] = useState<string | null>(null);
  const dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  const todayName = dayNames[new Date().getDay() === 0 ? 6 : new Date().getDay() - 1];
  const selectedWorkout = selectedDay && workoutPlan ? workoutPlan.days[selectedDay] : todayWorkout;

  return (
    <div className="space-y-6 animate-fade-in">
      <div><h1 className="text-3xl font-heading font-bold">Workouts</h1><p className="text-muted-foreground mt-1">Your weekly training plan</p></div>
      <div className="flex gap-2 overflow-x-auto pb-2">{dayNames.map((day) => (<button key={day} onClick={() => setSelectedDay(day)} className={`flex-shrink-0 px-4 py-2 rounded-xl font-medium transition-all ${(selectedDay || todayName) === day ? 'bg-primary text-primary-foreground' : 'bg-secondary hover:bg-secondary/80'}`}><p className="text-sm">{day.slice(0, 3)}</p></button>))}</div>
      {selectedWorkout?.exercises?.length > 0 ? (<div className="space-y-4"><Card className="gradient-accent text-accent-foreground"><CardContent className="p-6"><h2 className="text-xl font-bold">{selectedWorkout.focus}</h2><p className="opacity-80">{selectedWorkout.exercises.length} exercises • ~{selectedWorkout.totalDuration} min</p></CardContent></Card>
        {selectedWorkout.exercises.map((item: any, index: number) => (<Card key={index}><CardContent className="p-4"><div className="flex items-start gap-4"><div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground font-bold">{index + 1}</div><div className="flex-1"><h3 className="font-semibold">{item.exercise.name}</h3><p className="text-sm text-muted-foreground">{item.exercise.description}</p><div className="flex gap-4 mt-2 text-sm"><span className="text-primary font-medium">{item.sets} sets</span><span className="text-primary font-medium">{item.reps} reps</span></div>{item.exercise.videos?.length > 0 && (<div className="mt-4">{playingVideo === item.exercise.id ? (<div className="relative aspect-video rounded-xl overflow-hidden bg-secondary"><iframe src={item.exercise.videos[0]} className="absolute inset-0 w-full h-full" allowFullScreen /><button onClick={() => setPlayingVideo(null)} className="absolute top-2 right-2 p-2 rounded-lg bg-background/80"><X className="w-4 h-4" /></button></div>) : (<Button variant="outline" size="sm" onClick={() => setPlayingVideo(item.exercise.id)} className="gap-2"><Play className="w-4 h-4" />Watch Tutorial</Button>)}</div>)}</div><Checkbox /></div></CardContent></Card>))}</div>) : (<Card><CardContent className="p-12 text-center"><p className="text-4xl mb-4">🧘</p><h3 className="text-xl font-semibold">Rest Day</h3><p className="text-muted-foreground mt-2">Recovery is part of the journey!</p></CardContent></Card>)}
    </div>
  );
}

function WaterTab({ user, waterCount, waterProgress, addWater, removeWater }: any) {
  const circumference = 2 * Math.PI * 90;
  const strokeDashoffset = circumference - (Math.min(waterProgress, 100) / 100) * circumference;
  const getLast7Days = () => { const days = []; for (let i = 6; i >= 0; i--) { const date = new Date(); date.setDate(date.getDate() - i); const dateStr = date.toISOString().split('T')[0]; days.push({ date: dateStr, day: date.toLocaleDateString('en-US', { weekday: 'short' }), count: user.waterLogs[dateStr] || 0 }); } return days; };
  return (
    <div className="space-y-6 animate-fade-in">
      <div><h1 className="text-3xl font-heading font-bold">Water Tracker</h1><p className="text-muted-foreground mt-1">Stay hydrated throughout the day</p></div>
      <Card><CardContent className="p-8 flex flex-col items-center"><div className="relative"><svg className="progress-ring w-48 h-48"><circle className="stroke-secondary" strokeWidth="12" fill="transparent" r="90" cx="96" cy="96" /><circle className="progress-ring-circle stroke-blue-500" strokeWidth="12" strokeLinecap="round" fill="transparent" r="90" cx="96" cy="96" style={{ strokeDasharray: circumference, strokeDashoffset }} /></svg><div className="absolute inset-0 flex flex-col items-center justify-center"><Droplets className="w-8 h-8 text-blue-500 mb-2" /><p className="text-4xl font-bold">{waterCount}</p><p className="text-sm text-muted-foreground">of {user.settings.dailyWaterGoal} glasses</p></div></div><div className="flex gap-4 mt-8"><Button variant="outline" size="lg" onClick={removeWater} disabled={waterCount === 0} className="w-16 h-16 rounded-2xl"><Minus className="w-6 h-6" /></Button><Button size="lg" onClick={addWater} className="w-24 h-16 rounded-2xl gradient-primary text-primary-foreground shadow-glow"><Plus className="w-6 h-6 mr-2" />Add</Button></div></CardContent></Card>
      <Card><CardHeader><CardTitle>Last 7 Days</CardTitle></CardHeader><CardContent><div className="flex justify-between">{getLast7Days().map((day) => (<div key={day.date} className="text-center"><p className="text-xs text-muted-foreground mb-2">{day.day}</p><div className="w-10 h-24 rounded-lg bg-secondary relative overflow-hidden"><div className="absolute bottom-0 left-0 right-0 bg-blue-500 transition-all duration-500" style={{ height: `${Math.min((day.count / user.settings.dailyWaterGoal) * 100, 100)}%` }} /></div><p className="text-sm font-medium mt-2">{day.count}</p></div>))}</div></CardContent></Card>
    </div>
  );
}
