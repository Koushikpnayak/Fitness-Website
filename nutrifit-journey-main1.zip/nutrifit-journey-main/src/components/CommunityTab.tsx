import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { ChatMessage, ChatReply, PrivateMessage } from '@/lib/data';
import { 
  getChatMessages, saveChatMessage, deleteChatMessage,
  getPrivateMessages, savePrivateMessage, markMessageAsRead,
  getUsers
} from '@/lib/storage';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from '@/hooks/use-toast';
import {
  MessageCircle, Send, Heart, Reply, Search, Filter,
  User, Users, Dumbbell, TrendingUp, Image as ImageIcon,
  MoreHorizontal, Trash2, X, Plus, Mail
} from 'lucide-react';

interface CommunityTabProps {
  showMessaging?: boolean;
}

export function CommunityTab({ showMessaging = true }: CommunityTabProps) {
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [privateMessages, setPrivateMessages] = useState<PrivateMessage[]>([]);
  const [newPost, setNewPost] = useState('');
  const [postType, setPostType] = useState<'post' | 'progress' | 'question' | 'partner'>('post');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterTag, setFilterTag] = useState<string | null>(null);
  const [showCompose, setShowCompose] = useState(false);
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');
  const [dmRecipient, setDmRecipient] = useState<string | null>(null);
  const [dmText, setDmText] = useState('');
  const [activeTab, setActiveTab] = useState('feed');

  useEffect(() => {
    loadMessages();
    loadPrivateMessages();
  }, []);

  const loadMessages = () => {
    const msgs = getChatMessages().sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
    setMessages(msgs);
  };

  const loadPrivateMessages = () => {
    if (!user) return;
    const pms = getPrivateMessages().filter(
      m => m.fromUserId === user.id || m.toUserId === user.id
    );
    setPrivateMessages(pms);
  };

  const handlePost = () => {
    if (!user || !newPost.trim()) return;

    const message: ChatMessage = {
      id: `msg-${Date.now()}`,
      userId: user.id,
      username: user.name || 'Anonymous',
      text: newPost,
      timestamp: new Date().toISOString(),
      tags: postType === 'partner' ? ['workout partner'] : [],
      likes: [],
      replies: [],
      type: postType,
    };

    saveChatMessage(message);
    setNewPost('');
    setShowCompose(false);
    loadMessages();
    toast({ title: 'Posted successfully! 🎉' });
  };

  const handleLike = (messageId: string) => {
    if (!user) return;
    
    const message = messages.find(m => m.id === messageId);
    if (!message) return;

    const hasLiked = message.likes.includes(user.id);
    const updatedLikes = hasLiked
      ? message.likes.filter(id => id !== user.id)
      : [...message.likes, user.id];

    saveChatMessage({ ...message, likes: updatedLikes });
    loadMessages();
  };

  const handleReply = (messageId: string) => {
    if (!user || !replyText.trim()) return;

    const message = messages.find(m => m.id === messageId);
    if (!message) return;

    const reply: ChatReply = {
      id: `reply-${Date.now()}`,
      userId: user.id,
      username: user.name || 'Anonymous',
      text: replyText,
      timestamp: new Date().toISOString(),
    };

    saveChatMessage({
      ...message,
      replies: [...message.replies, reply],
    });

    setReplyText('');
    setReplyingTo(null);
    loadMessages();
  };

  const handleDelete = (messageId: string) => {
    if (!user?.isAdmin) return;
    deleteChatMessage(messageId);
    loadMessages();
    toast({ title: 'Message deleted' });
  };

  const handleSendDM = (toUserId: string, toUsername: string) => {
    if (!user || !dmText.trim()) return;

    const pm: PrivateMessage = {
      id: `pm-${Date.now()}`,
      fromUserId: user.id,
      fromUsername: user.name || 'Anonymous',
      toUserId,
      toUsername,
      text: dmText,
      timestamp: new Date().toISOString(),
      read: false,
    };

    savePrivateMessage(pm);
    setDmText('');
    setDmRecipient(null);
    loadPrivateMessages();
    toast({ title: 'Message sent!' });
  };

  const filteredMessages = messages.filter(m => {
    if (searchQuery && !m.text.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    if (filterTag === 'partner' && m.type !== 'partner') {
      return false;
    }
    if (filterTag === 'progress' && m.type !== 'progress') {
      return false;
    }
    if (filterTag === 'question' && m.type !== 'question') {
      return false;
    }
    return true;
  });

  const typeIcons = {
    post: MessageCircle,
    progress: TrendingUp,
    question: MessageCircle,
    partner: Users,
  };

  const typeColors = {
    post: 'bg-secondary',
    progress: 'bg-success/20 text-success',
    question: 'bg-accent/20 text-accent',
    partner: 'bg-primary/20 text-primary',
  };

  const unreadCount = privateMessages.filter(m => m.toUserId === user?.id && !m.read).length;

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-heading font-bold">Community</h1>
          <p className="text-muted-foreground mt-1">Connect with fellow fitness enthusiasts</p>
        </div>
        <Button
          onClick={() => setShowCompose(true)}
          className="gradient-primary text-primary-foreground shadow-glow"
        >
          <Plus className="w-5 h-5 mr-2" />
          New Post
        </Button>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="feed" className="gap-2">
            <MessageCircle className="w-4 h-4" />
            Feed
          </TabsTrigger>
          <TabsTrigger value="messages" className="gap-2 relative">
            <Mail className="w-4 h-4" />
            Messages
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-accent rounded-full text-xs flex items-center justify-center">
                {unreadCount}
              </span>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="feed" className="space-y-4 mt-4">
          {/* Search and Filter */}
          <div className="flex gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Search posts..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-12 rounded-xl"
              />
            </div>
          </div>

          {/* Filter Tags */}
          <div className="flex gap-2 flex-wrap">
            <Button
              variant={filterTag === null ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilterTag(null)}
              className="rounded-full"
            >
              All
            </Button>
            <Button
              variant={filterTag === 'progress' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilterTag('progress')}
              className="rounded-full"
            >
              <TrendingUp className="w-4 h-4 mr-1" />
              Progress
            </Button>
            <Button
              variant={filterTag === 'partner' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilterTag('partner')}
              className="rounded-full"
            >
              <Users className="w-4 h-4 mr-1" />
              Partner Wanted
            </Button>
            <Button
              variant={filterTag === 'question' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilterTag('question')}
              className="rounded-full"
            >
              <MessageCircle className="w-4 h-4 mr-1" />
              Questions
            </Button>
          </div>

          {/* Posts */}
          <div className="space-y-4">
            {filteredMessages.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <MessageCircle className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-xl font-semibold">No posts yet</h3>
                  <p className="text-muted-foreground mt-2">Be the first to share something!</p>
                </CardContent>
              </Card>
            ) : (
              filteredMessages.map((message) => {
                const TypeIcon = typeIcons[message.type];
                return (
                  <Card key={message.id} className="overflow-hidden">
                    <CardContent className="p-4">
                      {/* Header */}
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold">
                            {message.username[0]?.toUpperCase()}
                          </div>
                          <div>
                            <p className="font-semibold">{message.username}</p>
                            <p className="text-xs text-muted-foreground">
                              {new Date(message.timestamp).toLocaleDateString('en-US', {
                                month: 'short',
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge className={typeColors[message.type]}>
                            <TypeIcon className="w-3 h-3 mr-1" />
                            {message.type}
                          </Badge>
                          {user?.isAdmin && (
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDelete(message.id)}
                              className="text-destructive hover:text-destructive"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      </div>

                      {/* Content */}
                      <p className="text-foreground mb-4 whitespace-pre-wrap">{message.text}</p>

                      {/* Actions */}
                      <div className="flex items-center gap-4 border-t border-border pt-3">
                        <button
                          onClick={() => handleLike(message.id)}
                          className={`flex items-center gap-1 text-sm transition-colors ${
                            message.likes.includes(user?.id || '')
                              ? 'text-red-500'
                              : 'text-muted-foreground hover:text-red-500'
                          }`}
                        >
                          <Heart className={`w-4 h-4 ${message.likes.includes(user?.id || '') ? 'fill-current' : ''}`} />
                          {message.likes.length}
                        </button>
                        <button
                          onClick={() => setReplyingTo(replyingTo === message.id ? null : message.id)}
                          className="flex items-center gap-1 text-sm text-muted-foreground hover:text-primary transition-colors"
                        >
                          <Reply className="w-4 h-4" />
                          {message.replies.length}
                        </button>
                        {message.userId !== user?.id && (
                          <button
                            onClick={() => setDmRecipient(message.userId)}
                            className="flex items-center gap-1 text-sm text-muted-foreground hover:text-primary transition-colors ml-auto"
                          >
                            <Mail className="w-4 h-4" />
                            Message
                          </button>
                        )}
                      </div>

                      {/* Replies */}
                      {message.replies.length > 0 && (
                        <div className="mt-4 space-y-3 pl-4 border-l-2 border-border">
                          {message.replies.map((reply) => (
                            <div key={reply.id} className="text-sm">
                              <span className="font-semibold">{reply.username}</span>
                              <span className="text-muted-foreground mx-2">·</span>
                              <span className="text-xs text-muted-foreground">
                                {new Date(reply.timestamp).toLocaleDateString()}
                              </span>
                              <p className="mt-1">{reply.text}</p>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Reply Input */}
                      {replyingTo === message.id && (
                        <div className="mt-4 flex gap-2">
                          <Input
                            placeholder="Write a reply..."
                            value={replyText}
                            onChange={(e) => setReplyText(e.target.value)}
                            className="flex-1"
                          />
                          <Button onClick={() => handleReply(message.id)} size="icon">
                            <Send className="w-4 h-4" />
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })
            )}
          </div>
        </TabsContent>

        <TabsContent value="messages" className="space-y-4 mt-4">
          {privateMessages.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <Mail className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-xl font-semibold">No messages yet</h3>
                <p className="text-muted-foreground mt-2">Start a conversation from someone's post!</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {privateMessages
                .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
                .map((pm) => {
                  const isSent = pm.fromUserId === user?.id;
                  return (
                    <Card key={pm.id} className={!pm.read && !isSent ? 'border-primary' : ''}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-sm ${
                              isSent ? 'bg-secondary text-secondary-foreground' : 'bg-primary'
                            }`}>
                              {isSent ? pm.toUsername[0] : pm.fromUsername[0]}
                            </div>
                            <div>
                              <p className="font-medium text-sm">
                                {isSent ? `To: ${pm.toUsername}` : `From: ${pm.fromUsername}`}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {new Date(pm.timestamp).toLocaleString()}
                              </p>
                            </div>
                          </div>
                          {!pm.read && !isSent && (
                            <Badge className="bg-primary text-primary-foreground">New</Badge>
                          )}
                        </div>
                        <p className="text-sm">{pm.text}</p>
                        {!isSent && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="mt-3"
                            onClick={() => {
                              markMessageAsRead(pm.id);
                              setDmRecipient(pm.fromUserId);
                              loadPrivateMessages();
                            }}
                          >
                            Reply
                          </Button>
                        )}
                      </CardContent>
                    </Card>
                  );
                })}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Compose Post Modal */}
      {showCompose && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm p-4">
          <Card className="w-full max-w-lg animate-scale-in">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Create Post</CardTitle>
              <Button variant="ghost" size="icon" onClick={() => setShowCompose(false)}>
                <X className="w-5 h-5" />
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                {(['post', 'progress', 'question', 'partner'] as const).map((type) => (
                  <Button
                    key={type}
                    variant={postType === type ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setPostType(type)}
                    className="capitalize"
                  >
                    {type === 'partner' ? 'Find Partner' : type}
                  </Button>
                ))}
              </div>
              <Textarea
                placeholder={
                  postType === 'progress'
                    ? "Share your fitness progress..."
                    : postType === 'question'
                    ? "Ask the community..."
                    : postType === 'partner'
                    ? "Looking for a workout partner? Describe what you're looking for..."
                    : "What's on your mind?"
                }
                value={newPost}
                onChange={(e) => setNewPost(e.target.value)}
                rows={5}
              />
              <Button
                onClick={handlePost}
                disabled={!newPost.trim()}
                className="w-full gradient-primary text-primary-foreground"
              >
                <Send className="w-4 h-4 mr-2" />
                Post
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* DM Modal */}
      {dmRecipient && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm p-4">
          <Card className="w-full max-w-md animate-scale-in">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Send Message</CardTitle>
              <Button variant="ghost" size="icon" onClick={() => setDmRecipient(null)}>
                <X className="w-5 h-5" />
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                placeholder="Write your message..."
                value={dmText}
                onChange={(e) => setDmText(e.target.value)}
                rows={4}
              />
              <Button
                onClick={() => {
                  const recipient = messages.find(m => m.userId === dmRecipient);
                  if (recipient) {
                    handleSendDM(dmRecipient, recipient.username);
                  }
                }}
                disabled={!dmText.trim()}
                className="w-full"
              >
                <Send className="w-4 h-4 mr-2" />
                Send
              </Button>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
