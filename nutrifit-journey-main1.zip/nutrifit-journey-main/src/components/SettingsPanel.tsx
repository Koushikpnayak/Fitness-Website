import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Feedback } from '@/lib/data';
import { saveFeedback, exportUserData, importUserData } from '@/lib/storage';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { toast } from '@/hooks/use-toast';
import {
  Settings as SettingsIcon, User, Palette, Download, Upload,
  Trash2, Star, Droplets, Moon, Sun, Save, AlertTriangle
} from 'lucide-react';

export function SettingsPanel() {
  const { user, updateUser, logout, deleteAccount } = useAuth();
  const [showFeedback, setShowFeedback] = useState(false);
  const [feedbackTitle, setFeedbackTitle] = useState('');
  const [feedbackMessage, setFeedbackMessage] = useState('');
  const [feedbackRating, setFeedbackRating] = useState(5);
  
  const [editProfile, setEditProfile] = useState(false);
  const [profileData, setProfileData] = useState({
    name: user?.name || '',
    age: user?.age || 0,
    height: user?.height || 0,
    weight: user?.weight || 0,
  });

  const handleThemeToggle = () => {
    const newTheme = user?.settings.theme === 'dark' ? 'light' : 'dark';
    updateUser({
      settings: { ...user?.settings, theme: newTheme } as any,
    });
    // Note: In this app, we always use dark mode for the design
    toast({ title: `Theme preference saved` });
  };

  const handleWaterGoalChange = (value: number[]) => {
    updateUser({
      settings: { ...user?.settings, dailyWaterGoal: value[0] } as any,
    });
  };

  const handleGlassSizeChange = (value: number[]) => {
    updateUser({
      settings: { ...user?.settings, glassMl: value[0] } as any,
    });
  };

  const handleSaveProfile = () => {
    updateUser({
      name: profileData.name,
      age: Number(profileData.age),
      height: Number(profileData.height),
      weight: Number(profileData.weight),
    });
    setEditProfile(false);
    toast({ title: 'Profile updated!' });
  };

  const handleExportData = () => {
    if (!user) return;
    const data = exportUserData(user.id);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nutrifit-mydata-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: 'Your data has been exported!' });
  };

  const handleImportData = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (importUserData(user.id, result)) {
        window.location.reload();
      } else {
        toast({ title: 'Import failed', variant: 'destructive' });
      }
    };
    reader.readAsText(file);
  };

  const handleSubmitFeedback = () => {
    if (!user || !feedbackTitle || !feedbackMessage) return;

    const feedback: Feedback = {
      id: `fb-${Date.now()}`,
      userId: user.id,
      username: user.name || 'Anonymous',
      title: feedbackTitle,
      message: feedbackMessage,
      rating: feedbackRating,
      timestamp: new Date().toISOString(),
      addressed: false,
    };

    saveFeedback(feedback);
    setFeedbackTitle('');
    setFeedbackMessage('');
    setFeedbackRating(5);
    setShowFeedback(false);
    toast({ title: 'Thank you for your feedback! 🙏' });
  };

  const handleDeleteAccount = () => {
    if (confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
      if (confirm('This will permanently delete all your data. Type "DELETE" to confirm.')) {
        deleteAccount();
        toast({ title: 'Account deleted' });
      }
    }
  };

  if (!user) return null;

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-3xl font-heading font-bold">Settings</h1>
        <p className="text-muted-foreground mt-1">Manage your preferences</p>
      </div>

      {/* Profile Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="w-5 h-5 text-primary" />
            Profile
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {editProfile ? (
            <>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Name</Label>
                  <Input
                    value={profileData.name}
                    onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                    className="mt-2"
                  />
                </div>
                <div>
                  <Label>Age</Label>
                  <Input
                    type="number"
                    value={profileData.age}
                    onChange={(e) => setProfileData({ ...profileData, age: parseInt(e.target.value) })}
                    className="mt-2"
                  />
                </div>
                <div>
                  <Label>Height (cm)</Label>
                  <Input
                    type="number"
                    value={profileData.height}
                    onChange={(e) => setProfileData({ ...profileData, height: parseInt(e.target.value) })}
                    className="mt-2"
                  />
                </div>
                <div>
                  <Label>Weight (kg)</Label>
                  <Input
                    type="number"
                    value={profileData.weight}
                    onChange={(e) => setProfileData({ ...profileData, weight: parseInt(e.target.value) })}
                    className="mt-2"
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Button onClick={handleSaveProfile} className="gradient-primary">
                  <Save className="w-4 h-4 mr-2" />
                  Save
                </Button>
                <Button variant="outline" onClick={() => setEditProfile(false)}>
                  Cancel
                </Button>
              </div>
            </>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Name</p>
                  <p className="font-medium">{user.name || 'Not set'}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Age</p>
                  <p className="font-medium">{user.age} years</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Height</p>
                  <p className="font-medium">{user.height} cm</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Weight</p>
                  <p className="font-medium">{user.weight} kg</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Goal</p>
                  <p className="font-medium capitalize">{user.goal}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Level</p>
                  <p className="font-medium capitalize">{user.level}</p>
                </div>
              </div>
              <Button variant="outline" onClick={() => setEditProfile(true)}>
                Edit Profile
              </Button>
            </>
          )}
        </CardContent>
      </Card>

      {/* Appearance */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Palette className="w-5 h-5 text-primary" />
            Appearance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {user.settings.theme === 'dark' ? (
                <Moon className="w-5 h-5 text-muted-foreground" />
              ) : (
                <Sun className="w-5 h-5 text-yellow-500" />
              )}
              <div>
                <p className="font-medium">Dark Mode</p>
                <p className="text-sm text-muted-foreground">Toggle dark/light theme</p>
              </div>
            </div>
            <Switch
              checked={user.settings.theme === 'dark'}
              onCheckedChange={handleThemeToggle}
            />
          </div>
        </CardContent>
      </Card>

      {/* Water Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Droplets className="w-5 h-5 text-blue-500" />
            Water Tracker
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <div className="flex justify-between mb-2">
              <Label>Daily Water Goal</Label>
              <span className="text-sm font-medium">{user.settings.dailyWaterGoal} glasses</span>
            </div>
            <Slider
              value={[user.settings.dailyWaterGoal]}
              onValueChange={handleWaterGoalChange}
              min={4}
              max={16}
              step={1}
            />
          </div>
          <div>
            <div className="flex justify-between mb-2">
              <Label>Glass Size</Label>
              <span className="text-sm font-medium">{user.settings.glassMl} ml</span>
            </div>
            <Slider
              value={[user.settings.glassMl]}
              onValueChange={handleGlassSizeChange}
              min={150}
              max={500}
              step={50}
            />
          </div>
        </CardContent>
      </Card>

      {/* Data Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <SettingsIcon className="w-5 h-5 text-primary" />
            Data Management
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Export My Data</p>
              <p className="text-sm text-muted-foreground">Download all your data as JSON</p>
            </div>
            <Button variant="outline" onClick={handleExportData}>
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Import Data</p>
              <p className="text-sm text-muted-foreground">Restore from a backup file</p>
            </div>
            <label>
              <Button variant="outline" asChild>
                <span>
                  <Upload className="w-4 h-4 mr-2" />
                  Import
                </span>
              </Button>
              <input
                type="file"
                accept=".json"
                onChange={handleImportData}
                className="hidden"
              />
            </label>
          </div>
        </CardContent>
      </Card>

      {/* Feedback */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Star className="w-5 h-5 text-yellow-500" />
            Feedback
          </CardTitle>
        </CardHeader>
        <CardContent>
          {showFeedback ? (
            <div className="space-y-4">
              <div>
                <Label>Title</Label>
                <Input
                  value={feedbackTitle}
                  onChange={(e) => setFeedbackTitle(e.target.value)}
                  placeholder="Brief summary"
                  className="mt-2"
                />
              </div>
              <div>
                <Label>Message</Label>
                <Textarea
                  value={feedbackMessage}
                  onChange={(e) => setFeedbackMessage(e.target.value)}
                  placeholder="Tell us more..."
                  className="mt-2"
                  rows={4}
                />
              </div>
              <div>
                <Label>Rating</Label>
                <div className="flex gap-2 mt-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      onClick={() => setFeedbackRating(star)}
                      className="transition-transform hover:scale-110"
                    >
                      <Star
                        className={`w-8 h-8 ${
                          star <= feedbackRating
                            ? 'fill-yellow-500 text-yellow-500'
                            : 'text-muted'
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex gap-2">
                <Button onClick={handleSubmitFeedback} className="gradient-primary">
                  Submit Feedback
                </Button>
                <Button variant="outline" onClick={() => setShowFeedback(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            <Button onClick={() => setShowFeedback(true)}>
              <Star className="w-4 h-4 mr-2" />
              Send Feedback
            </Button>
          )}
        </CardContent>
      </Card>

      {/* Danger Zone */}
      <Card className="border-destructive/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-destructive">
            <AlertTriangle className="w-5 h-5" />
            Danger Zone
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Delete Account</p>
              <p className="text-sm text-muted-foreground">Permanently delete your account and all data</p>
            </div>
            <Button variant="destructive" onClick={handleDeleteAccount}>
              <Trash2 className="w-4 h-4 mr-2" />
              Delete Account
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Security Notice */}
      <Card className="border-yellow-500/30 bg-yellow-500/5">
        <CardContent className="p-4">
          <p className="text-sm text-muted-foreground">
            <strong>⚠️ Demo App Notice:</strong> This is a client-only demo app. All data is stored in your browser's localStorage. 
            For production use, implement secure server-side authentication with HTTPS, proper password hashing, and access control.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
