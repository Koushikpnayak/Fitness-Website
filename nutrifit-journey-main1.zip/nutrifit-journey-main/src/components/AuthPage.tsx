import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { toast } from '@/hooks/use-toast';
import { Dumbbell, Mail, Lock, Eye, EyeOff, ChevronRight, Sparkles } from 'lucide-react';

export function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const { login, signup, loading } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !password) {
      toast({
        title: 'Missing fields',
        description: 'Please enter both email and password.',
        variant: 'destructive',
      });
      return;
    }

    if (password.length < 6) {
      toast({
        title: 'Password too short',
        description: 'Password must be at least 6 characters.',
        variant: 'destructive',
      });
      return;
    }

    const result = isLogin 
      ? await login(email, password)
      : await signup(email, password);

    if (!result.success) {
      toast({
        title: isLogin ? 'Login failed' : 'Signup failed',
        description: result.error,
        variant: 'destructive',
      });
    } else if (!isLogin) {
      toast({
        title: 'Account created!',
        description: 'Welcome to NutriFit. Let\'s set up your profile.',
      });
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Left side - Branding */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden bg-gradient-to-br from-primary/20 via-background to-accent/10">
        {/* Animated background elements */}
        <div className="absolute inset-0">
          <div className="absolute top-20 left-20 w-72 h-72 bg-primary/20 rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-accent/20 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }} />
          <div className="absolute top-1/2 left-1/3 w-64 h-64 bg-success/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '4s' }} />
        </div>
        
        {/* Grid pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(20,184,166,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(20,184,166,0.03)_1px,transparent_1px)] bg-[size:60px_60px]" />
        
        <div className="relative z-10 flex flex-col justify-center px-16">
          <div className="flex items-center gap-3 mb-8">
            <div className="p-3 rounded-2xl gradient-primary shadow-glow">
              <Dumbbell className="w-10 h-10 text-primary-foreground" />
            </div>
            <span className="text-4xl font-heading font-bold">NutriFit</span>
          </div>
          
          <h1 className="text-5xl font-heading font-bold leading-tight mb-6">
            Transform Your
            <span className="gradient-text block">Health Journey</span>
          </h1>
          
          <p className="text-lg text-muted-foreground max-w-md mb-8">
            Personalized meal plans, AI-powered workout routines, and a supportive community to help you achieve your fitness goals.
          </p>

          <div className="flex flex-col gap-4">
            {[
              'Smart nutrition tracking with Indian cuisine',
              'Personalized workout plans with video tutorials',
              'Community support & workout partners',
            ].map((feature, i) => (
              <div key={i} className="flex items-center gap-3 animate-slide-in-left" style={{ animationDelay: `${i * 0.2}s` }}>
                <div className="w-2 h-2 rounded-full bg-primary" />
                <span className="text-muted-foreground">{feature}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right side - Auth form */}
      <div className="flex-1 flex items-center justify-center p-8 bg-background">
        <div className="w-full max-w-md">
          {/* Mobile logo */}
          <div className="lg:hidden flex items-center justify-center gap-2 mb-8">
            <div className="p-2 rounded-xl gradient-primary shadow-glow">
              <Dumbbell className="w-6 h-6 text-primary-foreground" />
            </div>
            <span className="text-2xl font-heading font-bold">NutriFit</span>
          </div>

          <div className="glass rounded-3xl p-8 shadow-lg animate-scale-in">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-2xl font-heading font-bold">
                  {isLogin ? 'Welcome back' : 'Create account'}
                </h2>
                <p className="text-muted-foreground text-sm mt-1">
                  {isLogin ? 'Sign in to continue your journey' : 'Start your fitness transformation'}
                </p>
              </div>
              <Sparkles className="w-8 h-8 text-accent animate-bounce-subtle" />
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm font-medium">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-10 h-12 rounded-xl bg-secondary/50 border-border/50 focus:bg-background transition-colors"
                    disabled={loading}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-sm font-medium">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 pr-10 h-12 rounded-xl bg-secondary/50 border-border/50 focus:bg-background transition-colors"
                    disabled={loading}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <Button
                type="submit"
                disabled={loading}
                className="w-full h-12 rounded-xl gradient-primary text-primary-foreground font-semibold shadow-glow hover:shadow-lg transition-all duration-300 btn-glow"
              >
                {loading ? (
                  <LoadingSpinner size="sm" />
                ) : (
                  <>
                    {isLogin ? 'Sign In' : 'Create Account'}
                    <ChevronRight className="w-5 h-5 ml-2" />
                  </>
                )}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <button
                type="button"
                onClick={() => setIsLogin(!isLogin)}
                className="text-sm text-muted-foreground hover:text-primary transition-colors"
              >
                {isLogin ? "Don't have an account? " : 'Already have an account? '}
                <span className="font-semibold text-primary">
                  {isLogin ? 'Sign up' : 'Sign in'}
                </span>
              </button>
            </div>

            {isLogin && (
              <div className="mt-4 p-3 rounded-xl bg-secondary/50 border border-border/30">
                <p className="text-xs text-muted-foreground text-center">
                  <strong>Admin access:</strong> koushikmreddy43@gmail.com / admin123
                </p>
              </div>
            )}
          </div>

          {/* Security notice */}
          <p className="mt-6 text-xs text-center text-muted-foreground px-4">
            Demo app with client-side storage. For production, use secure server-side authentication.
          </p>
        </div>
      </div>
    </div>
  );
}
