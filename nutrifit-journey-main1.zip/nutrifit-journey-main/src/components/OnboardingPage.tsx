import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from '@/hooks/use-toast';
import { ALLERGEN_OPTIONS } from '@/lib/data';
import { LoadingSpinner } from '@/components/LoadingSpinner';
import { 
  User, Scale, Ruler, Target, Activity, Utensils, 
  ChevronRight, ChevronLeft, Check, Sparkles 
} from 'lucide-react';

const GOALS = [
  { value: 'weight loss', label: 'Weight Loss', icon: '🔥', desc: 'Burn fat & get lean' },
  { value: 'weight gain', label: 'Weight Gain', icon: '📈', desc: 'Healthy mass building' },
  { value: 'muscle gain', label: 'Muscle Gain', icon: '💪', desc: 'Build strength & size' },
  { value: 'cardio', label: 'Cardio Fitness', icon: '🏃', desc: 'Improve endurance' },
  { value: 'flexibility', label: 'Flexibility', icon: '🧘', desc: 'Stretch & mobility' },
  { value: 'general health', label: 'General Health', icon: '❤️', desc: 'Overall wellness' },
];

const LEVELS = [
  { value: 'beginner', label: 'Beginner', desc: 'New to fitness' },
  { value: 'intermediate', label: 'Intermediate', desc: '1-3 years experience' },
  { value: 'advanced', label: 'Advanced', desc: '3+ years experience' },
];

const DIETS = [
  { value: 'vegetarian', label: 'Vegetarian', icon: '🥬' },
  { value: 'non-vegetarian', label: 'Non-Vegetarian', icon: '🍗' },
];

const CUISINES = [
  { value: 'south-indian', label: 'South Indian', icon: '🍚' },
  { value: 'north-indian', label: 'North Indian', icon: '🫓' },
  { value: 'both', label: 'Both', icon: '🍽️' },
  { value: 'other', label: 'Other', icon: '🌍' },
];

const ACTIVITY_LEVELS = [
  { value: 'sedentary', label: 'Sedentary', desc: 'Little or no exercise' },
  { value: 'moderate', label: 'Moderate', desc: 'Exercise 3-5 days/week' },
  { value: 'active', label: 'Active', desc: 'Exercise 6-7 days/week' },
];

export function OnboardingPage() {
  const { user, updateUser } = useAuth();
  const [step, setStep] = useState(1);
  const [saving, setSaving] = useState(false);
  
  const [formData, setFormData] = useState({
    name: user?.name || '',
    age: user?.age || '',
    height: user?.height || '',
    weight: user?.weight || '',
    goal: user?.goal || '',
    level: user?.level || '',
    diet: user?.diet || '',
    cuisine: user?.cuisine || '',
    allergies: user?.allergies || [],
    activityLevel: user?.activityLevel || 'moderate',
    sleepHours: user?.sleepHours || 7,
    preferredWorkoutTime: user?.preferredWorkoutTime || '07:00',
  });

  const totalSteps = 4;

  const updateField = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const toggleAllergy = (allergy: string) => {
    setFormData(prev => ({
      ...prev,
      allergies: prev.allergies.includes(allergy)
        ? prev.allergies.filter(a => a !== allergy)
        : [...prev.allergies, allergy],
    }));
  };

  const canProceed = () => {
    switch (step) {
      case 1:
        return formData.name && formData.age && formData.height && formData.weight;
      case 2:
        return formData.goal && formData.level;
      case 3:
        return formData.diet && formData.cuisine;
      case 4:
        return true;
      default:
        return false;
    }
  };

  const handleNext = () => {
    if (canProceed() && step < totalSteps) {
      setStep(step + 1);
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const handleComplete = async () => {
    setSaving(true);
    
    // Simulate save delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    updateUser({
      name: formData.name,
      age: Number(formData.age),
      height: Number(formData.height),
      weight: Number(formData.weight),
      goal: formData.goal,
      level: formData.level,
      diet: formData.diet,
      cuisine: formData.cuisine,
      allergies: formData.allergies,
      activityLevel: formData.activityLevel,
      sleepHours: Number(formData.sleepHours),
      preferredWorkoutTime: formData.preferredWorkoutTime,
      onboardingComplete: true,
    });
    
    toast({
      title: 'Profile complete! 🎉',
      description: 'Your personalized plan is ready.',
    });
    
    setSaving(false);
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-6 animate-fade-in">
            <div className="text-center mb-8">
              <div className="inline-flex p-4 rounded-2xl bg-primary/10 mb-4">
                <User className="w-8 h-8 text-primary" />
              </div>
              <h2 className="text-2xl font-heading font-bold">Basic Information</h2>
              <p className="text-muted-foreground mt-1">Tell us about yourself</p>
            </div>

            <div className="space-y-4">
              <div>
                <Label>Full Name</Label>
                <Input
                  value={formData.name}
                  onChange={(e) => updateField('name', e.target.value)}
                  placeholder="Enter your name"
                  className="h-12 rounded-xl mt-2"
                />
              </div>
              
              <div>
                <Label>Age</Label>
                <Input
                  type="number"
                  value={formData.age}
                  onChange={(e) => updateField('age', e.target.value)}
                  placeholder="Years"
                  className="h-12 rounded-xl mt-2"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Height (cm)</Label>
                  <div className="relative mt-2">
                    <Ruler className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      type="number"
                      value={formData.height}
                      onChange={(e) => updateField('height', e.target.value)}
                      placeholder="170"
                      className="h-12 rounded-xl pl-10"
                    />
                  </div>
                </div>
                <div>
                  <Label>Weight (kg)</Label>
                  <div className="relative mt-2">
                    <Scale className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      type="number"
                      value={formData.weight}
                      onChange={(e) => updateField('weight', e.target.value)}
                      placeholder="70"
                      className="h-12 rounded-xl pl-10"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6 animate-fade-in">
            <div className="text-center mb-8">
              <div className="inline-flex p-4 rounded-2xl bg-accent/10 mb-4">
                <Target className="w-8 h-8 text-accent" />
              </div>
              <h2 className="text-2xl font-heading font-bold">Fitness Goals</h2>
              <p className="text-muted-foreground mt-1">What do you want to achieve?</p>
            </div>

            <div className="space-y-4">
              <Label>Select Your Goal</Label>
              <div className="grid grid-cols-2 gap-3">
                {GOALS.map((goal) => (
                  <button
                    key={goal.value}
                    onClick={() => updateField('goal', goal.value)}
                    className={`p-4 rounded-xl border-2 text-left transition-all duration-300 ${
                      formData.goal === goal.value
                        ? 'border-primary bg-primary/10 shadow-glow'
                        : 'border-border hover:border-primary/50'
                    }`}
                  >
                    <span className="text-2xl">{goal.icon}</span>
                    <p className="font-semibold mt-2">{goal.label}</p>
                    <p className="text-xs text-muted-foreground">{goal.desc}</p>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <Label>Experience Level</Label>
              <div className="grid grid-cols-3 gap-3">
                {LEVELS.map((level) => (
                  <button
                    key={level.value}
                    onClick={() => updateField('level', level.value)}
                    className={`p-4 rounded-xl border-2 text-center transition-all duration-300 ${
                      formData.level === level.value
                        ? 'border-primary bg-primary/10'
                        : 'border-border hover:border-primary/50'
                    }`}
                  >
                    <p className="font-semibold">{level.label}</p>
                    <p className="text-xs text-muted-foreground mt-1">{level.desc}</p>
                  </button>
                ))}
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6 animate-fade-in">
            <div className="text-center mb-8">
              <div className="inline-flex p-4 rounded-2xl bg-success/10 mb-4">
                <Utensils className="w-8 h-8 text-success" />
              </div>
              <h2 className="text-2xl font-heading font-bold">Diet Preferences</h2>
              <p className="text-muted-foreground mt-1">Customize your meal plans</p>
            </div>

            <div className="space-y-4">
              <Label>Diet Type</Label>
              <div className="grid grid-cols-2 gap-3">
                {DIETS.map((diet) => (
                  <button
                    key={diet.value}
                    onClick={() => updateField('diet', diet.value)}
                    className={`p-4 rounded-xl border-2 text-center transition-all duration-300 ${
                      formData.diet === diet.value
                        ? 'border-primary bg-primary/10'
                        : 'border-border hover:border-primary/50'
                    }`}
                  >
                    <span className="text-3xl">{diet.icon}</span>
                    <p className="font-semibold mt-2">{diet.label}</p>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <Label>Cuisine Preference</Label>
              <div className="grid grid-cols-2 gap-3">
                {CUISINES.map((cuisine) => (
                  <button
                    key={cuisine.value}
                    onClick={() => updateField('cuisine', cuisine.value)}
                    className={`p-4 rounded-xl border-2 text-center transition-all duration-300 ${
                      formData.cuisine === cuisine.value
                        ? 'border-primary bg-primary/10'
                        : 'border-border hover:border-primary/50'
                    }`}
                  >
                    <span className="text-2xl">{cuisine.icon}</span>
                    <p className="font-semibold mt-1">{cuisine.label}</p>
                  </button>
                ))}
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6 animate-fade-in">
            <div className="text-center mb-8">
              <div className="inline-flex p-4 rounded-2xl bg-destructive/10 mb-4">
                <Activity className="w-8 h-8 text-destructive" />
              </div>
              <h2 className="text-2xl font-heading font-bold">Final Details</h2>
              <p className="text-muted-foreground mt-1">Almost there!</p>
            </div>

            <div className="space-y-4">
              <Label>Allergies (Select all that apply)</Label>
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-48 overflow-y-auto p-1">
                {ALLERGEN_OPTIONS.map((allergy) => (
                  <button
                    key={allergy}
                    onClick={() => toggleAllergy(allergy)}
                    className={`px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                      formData.allergies.includes(allergy)
                        ? 'bg-destructive text-destructive-foreground'
                        : 'bg-secondary hover:bg-secondary/80'
                    }`}
                  >
                    {allergy}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <Label>Activity Level</Label>
              <div className="grid grid-cols-3 gap-3">
                {ACTIVITY_LEVELS.map((level) => (
                  <button
                    key={level.value}
                    onClick={() => updateField('activityLevel', level.value)}
                    className={`p-3 rounded-xl border-2 text-center transition-all ${
                      formData.activityLevel === level.value
                        ? 'border-primary bg-primary/10'
                        : 'border-border hover:border-primary/50'
                    }`}
                  >
                    <p className="font-semibold text-sm">{level.label}</p>
                    <p className="text-xs text-muted-foreground">{level.desc}</p>
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Sleep Hours</Label>
                <Input
                  type="number"
                  value={formData.sleepHours}
                  onChange={(e) => updateField('sleepHours', e.target.value)}
                  min={4}
                  max={12}
                  className="h-12 rounded-xl mt-2"
                />
              </div>
              <div>
                <Label>Preferred Workout Time</Label>
                <Input
                  type="time"
                  value={formData.preferredWorkoutTime}
                  onChange={(e) => updateField('preferredWorkoutTime', e.target.value)}
                  className="h-12 rounded-xl mt-2"
                />
              </div>
            </div>
          </div>
        );
    }
  };

  if (saving) {
    return <LoadingSpinner fullScreen text="Setting up your personalized plan..." />;
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      {/* Background decorations */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />
      </div>

      <div className="w-full max-w-lg relative">
        {/* Progress indicator */}
        <div className="flex items-center justify-center gap-2 mb-8">
          {Array.from({ length: totalSteps }).map((_, i) => (
            <div
              key={i}
              className={`h-2 rounded-full transition-all duration-500 ${
                i + 1 <= step ? 'w-12 bg-primary' : 'w-8 bg-muted'
              }`}
            />
          ))}
        </div>

        <div className="glass rounded-3xl p-8 shadow-lg">
          {renderStep()}

          {/* Navigation buttons */}
          <div className="flex gap-3 mt-8">
            {step > 1 && (
              <Button
                variant="outline"
                onClick={handleBack}
                className="flex-1 h-12 rounded-xl"
              >
                <ChevronLeft className="w-5 h-5 mr-2" />
                Back
              </Button>
            )}
            
            {step < totalSteps ? (
              <Button
                onClick={handleNext}
                disabled={!canProceed()}
                className="flex-1 h-12 rounded-xl gradient-primary text-primary-foreground"
              >
                Next
                <ChevronRight className="w-5 h-5 ml-2" />
              </Button>
            ) : (
              <Button
                onClick={handleComplete}
                disabled={!canProceed()}
                className="flex-1 h-12 rounded-xl gradient-accent text-accent-foreground"
              >
                <Sparkles className="w-5 h-5 mr-2" />
                Complete Setup
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
