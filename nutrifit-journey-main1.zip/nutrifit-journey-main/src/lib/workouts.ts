// Workout plan generation for NutriFit

import { User, Exercise } from './data';
import { getExercises } from './storage';

export interface WorkoutPlanItem {
  exercise: Exercise;
  sets: number;
  reps: number;
  duration?: number;
  completed: boolean;
}

export interface DailyWorkoutPlan {
  dayName: string;
  focus: string;
  exercises: WorkoutPlanItem[];
  scheduledTime?: string;
  totalDuration: number;
}

export interface WeeklyWorkoutPlan {
  weekOf: string;
  days: Record<string, DailyWorkoutPlan>;
}

// Get workout days based on experience level
function getWorkoutDays(level: string): string[] {
  switch (level) {
    case 'beginner':
      return ['Monday', 'Wednesday', 'Friday'];
    case 'intermediate':
      return ['Monday', 'Tuesday', 'Thursday', 'Friday'];
    case 'advanced':
      return ['Monday', 'Tuesday', 'Wednesday', 'Friday', 'Saturday'];
    default:
      return ['Monday', 'Wednesday', 'Friday'];
  }
}

// Get exercise count per day based on level
function getExerciseCount(level: string): number {
  switch (level) {
    case 'beginner':
      return 4;
    case 'intermediate':
      return 5;
    case 'advanced':
      return 6;
    default:
      return 4;
  }
}

// Map goals to workout focus areas
function getWorkoutFocus(goal: string, dayIndex: number): { focus: string; categories: string[] } {
  const focusMap: Record<string, { focus: string; categories: string[] }[]> = {
    'weight loss': [
      { focus: 'Full Body HIIT', categories: ['cardio', 'hiit'] },
      { focus: 'Cardio & Core', categories: ['cardio', 'strength'] },
      { focus: 'HIIT & Strength', categories: ['hiit', 'strength'] },
    ],
    'weight gain': [
      { focus: 'Upper Body Strength', categories: ['strength'] },
      { focus: 'Lower Body Strength', categories: ['strength'] },
      { focus: 'Full Body Power', categories: ['strength', 'hiit'] },
    ],
    'muscle gain': [
      { focus: 'Push Day (Chest, Shoulders, Triceps)', categories: ['strength'] },
      { focus: 'Pull Day (Back, Biceps)', categories: ['strength'] },
      { focus: 'Legs & Core', categories: ['strength'] },
      { focus: 'Upper Body Hypertrophy', categories: ['strength'] },
      { focus: 'Lower Body Hypertrophy', categories: ['strength'] },
    ],
    'cardio': [
      { focus: 'Steady State Cardio', categories: ['cardio'] },
      { focus: 'HIIT Session', categories: ['hiit', 'cardio'] },
      { focus: 'Active Recovery', categories: ['flexibility', 'cardio'] },
    ],
    'flexibility': [
      { focus: 'Dynamic Stretching', categories: ['flexibility'] },
      { focus: 'Yoga Flow', categories: ['flexibility'] },
      { focus: 'Mobility & Recovery', categories: ['flexibility'] },
    ],
    'general health': [
      { focus: 'Full Body Workout', categories: ['strength', 'cardio'] },
      { focus: 'Cardio & Core', categories: ['cardio', 'strength'] },
      { focus: 'Strength & Flexibility', categories: ['strength', 'flexibility'] },
    ],
  };

  const focuses = focusMap[goal] || focusMap['general health'];
  return focuses[dayIndex % focuses.length];
}

// Generate weekly workout plan
export function generateWorkoutPlan(user: User): WeeklyWorkoutPlan {
  const exercises = getExercises();
  const workoutDays = getWorkoutDays(user.level);
  const exerciseCount = getExerciseCount(user.level);
  
  const days: Record<string, DailyWorkoutPlan> = {};
  const usedExerciseIds = new Set<string>();
  
  workoutDays.forEach((day, dayIndex) => {
    const { focus, categories } = getWorkoutFocus(user.goal, dayIndex);
    
    // Filter exercises by difficulty and categories
    let availableExercises = exercises.filter(e => {
      // Match difficulty
      if (user.level === 'beginner' && e.difficulty === 'advanced') return false;
      if (user.level === 'intermediate' && e.difficulty === 'advanced') {
        // Include some advanced for intermediate
        return Math.random() > 0.7;
      }
      
      // Match category
      return categories.includes(e.category);
    });
    
    // If not enough exercises in category, expand search
    if (availableExercises.length < exerciseCount) {
      availableExercises = exercises.filter(e => {
        if (user.level === 'beginner' && e.difficulty === 'advanced') return false;
        return e.goalFit.includes(user.goal);
      });
    }
    
    // Select exercises avoiding repeats across days when possible
    const dayExercises: WorkoutPlanItem[] = [];
    
    // Shuffle available exercises
    const shuffled = [...availableExercises].sort(() => Math.random() - 0.5);
    
    // Pick unique exercises
    for (const exercise of shuffled) {
      if (dayExercises.length >= exerciseCount) break;
      
      // Prefer unused exercises but allow reuse if needed
      if (!usedExerciseIds.has(exercise.id) || dayExercises.length < 2) {
        usedExerciseIds.add(exercise.id);
        
        // Adjust sets/reps based on level
        let sets = exercise.defaultSets;
        let reps = exercise.defaultReps;
        
        if (user.level === 'beginner') {
          sets = Math.max(2, sets - 1);
          reps = Math.max(8, reps - 2);
        } else if (user.level === 'advanced') {
          sets = Math.min(5, sets + 1);
          reps = Math.min(20, reps + 2);
        }
        
        dayExercises.push({
          exercise,
          sets,
          reps,
          duration: exercise.duration,
          completed: false,
        });
      }
    }
    
    // Calculate total duration (estimate: 3 min per set + 30 sec rest)
    const totalDuration = dayExercises.reduce((total, item) => {
      if (item.duration) {
        return total + item.duration * item.sets;
      }
      return total + (item.sets * 3); // 3 min per set approx
    }, 0);
    
    days[day] = {
      dayName: day,
      focus,
      exercises: dayExercises,
      scheduledTime: user.preferredWorkoutTime || '07:00',
      totalDuration: Math.round(totalDuration),
    };
  });
  
  // Rest days
  const allDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  allDays.forEach(day => {
    if (!days[day]) {
      days[day] = {
        dayName: day,
        focus: 'Rest Day',
        exercises: [],
        totalDuration: 0,
      };
    }
  });
  
  return {
    weekOf: new Date().toISOString().split('T')[0],
    days,
  };
}

// Get today's workout
export function getTodayWorkout(plan: WeeklyWorkoutPlan): DailyWorkoutPlan {
  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const today = dayNames[new Date().getDay()];
  return plan.days[today];
}
