// NutriFit Data - Foods, Exercises, and Seed Data

export interface Food {
  id: string;
  name: string;
  cuisine: 'south-indian' | 'north-indian' | 'both' | 'other';
  veg: boolean;
  caloriesPer100g: number;
  proteinPer100g: number;
  carbsPer100g: number;
  fatPer100g: number;
  allergens: string[];
  mealType: ('breakfast' | 'lunch' | 'dinner' | 'snack')[];
}

export interface Exercise {
  id: string;
  name: string;
  category: 'strength' | 'cardio' | 'flexibility' | 'hiit';
  description: string;
  defaultSets: number;
  defaultReps: number;
  duration?: number; // in minutes for cardio
  videos: string[];
  tags: string[];
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  muscleGroups: string[];
  goalFit: string[];
}

export interface User {
  id: string;
  email: string;
  passwordHash: string;
  name: string;
  age: number;
  height: number;
  weight: number;
  goal: string;
  level: string;
  diet: string;
  cuisine: string;
  allergies: string[];
  activityLevel?: string;
  sleepHours?: number;
  preferredWorkoutTime?: string;
  isAdmin: boolean;
  onboardingComplete: boolean;
  settings: {
    theme: 'light' | 'dark';
    glassMl: number;
    dailyWaterGoal: number;
  };
  waterLogs: Record<string, number>;
  workoutLogs: WorkoutLog[];
  mealOverrides: Record<string, MealOverride[]>;
  createdAt: string;
}

export interface WorkoutLog {
  id: string;
  date: string;
  exercises: { exerciseId: string; completed: boolean; sets: number; reps: number }[];
  notes: string;
  duration: number;
}

export interface MealOverride {
  foodId: string;
  grams: number;
  mealType: string;
}

export interface ChatMessage {
  id: string;
  userId: string;
  username: string;
  text: string;
  timestamp: string;
  tags: string[];
  likes: string[];
  replies: ChatReply[];
  type: 'post' | 'progress' | 'question' | 'partner';
  imageUrl?: string;
}

export interface ChatReply {
  id: string;
  userId: string;
  username: string;
  text: string;
  timestamp: string;
}

export interface PrivateMessage {
  id: string;
  fromUserId: string;
  fromUsername: string;
  toUserId: string;
  toUsername: string;
  text: string;
  timestamp: string;
  read: boolean;
}

export interface Feedback {
  id: string;
  userId: string;
  username: string;
  title: string;
  message: string;
  rating: number;
  timestamp: string;
  addressed: boolean;
}

// Allergen options
export const ALLERGEN_OPTIONS = [
  'Nuts', 'Dairy', 'Gluten', 'Soy', 'Eggs', 'Shellfish', 'Sesame', 'Peanut',
  'Mustard', 'Lactose', 'Sulphites', 'Tree Nuts', 'Fish', 'Wheat', 'Chickpea/Legume',
  'Corn', 'Yeast', 'Citrus', 'Nightshades', 'Coconut'
];

// Seed Foods Database
export const SEED_FOODS: Food[] = [
  // South Indian
  { id: 'f1', name: 'Idli', cuisine: 'south-indian', veg: true, caloriesPer100g: 58, proteinPer100g: 2, carbsPer100g: 12, fatPer100g: 0.2, allergens: [], mealType: ['breakfast'] },
  { id: 'f2', name: 'Dosa (Plain)', cuisine: 'south-indian', veg: true, caloriesPer100g: 168, proteinPer100g: 4, carbsPer100g: 28, fatPer100g: 4, allergens: [], mealType: ['breakfast', 'dinner'] },
  { id: 'f3', name: 'Sambar', cuisine: 'south-indian', veg: true, caloriesPer100g: 65, proteinPer100g: 3.5, carbsPer100g: 8, fatPer100g: 2, allergens: ['Chickpea/Legume'], mealType: ['breakfast', 'lunch', 'dinner'] },
  { id: 'f4', name: 'Coconut Chutney', cuisine: 'south-indian', veg: true, caloriesPer100g: 155, proteinPer100g: 2, carbsPer100g: 8, fatPer100g: 13, allergens: ['Coconut'], mealType: ['breakfast', 'lunch', 'dinner'] },
  { id: 'f5', name: 'Upma', cuisine: 'south-indian', veg: true, caloriesPer100g: 125, proteinPer100g: 3, carbsPer100g: 18, fatPer100g: 4, allergens: ['Gluten', 'Nuts'], mealType: ['breakfast'] },
  { id: 'f6', name: 'Pongal', cuisine: 'south-indian', veg: true, caloriesPer100g: 150, proteinPer100g: 4, carbsPer100g: 22, fatPer100g: 5, allergens: ['Nuts'], mealType: ['breakfast'] },
  { id: 'f7', name: 'Rasam', cuisine: 'south-indian', veg: true, caloriesPer100g: 30, proteinPer100g: 1, carbsPer100g: 5, fatPer100g: 0.5, allergens: [], mealType: ['lunch', 'dinner'] },
  { id: 'f8', name: 'Curd Rice', cuisine: 'south-indian', veg: true, caloriesPer100g: 95, proteinPer100g: 3, carbsPer100g: 16, fatPer100g: 2, allergens: ['Dairy', 'Lactose'], mealType: ['lunch', 'dinner'] },
  { id: 'f9', name: 'Chicken Chettinad', cuisine: 'south-indian', veg: false, caloriesPer100g: 180, proteinPer100g: 22, carbsPer100g: 4, fatPer100g: 9, allergens: [], mealType: ['lunch', 'dinner'] },
  { id: 'f10', name: 'Fish Curry (South)', cuisine: 'south-indian', veg: false, caloriesPer100g: 140, proteinPer100g: 18, carbsPer100g: 3, fatPer100g: 6, allergens: ['Fish', 'Coconut'], mealType: ['lunch', 'dinner'] },
  
  // North Indian
  { id: 'f11', name: 'Paratha (Plain)', cuisine: 'north-indian', veg: true, caloriesPer100g: 260, proteinPer100g: 5, carbsPer100g: 32, fatPer100g: 12, allergens: ['Gluten', 'Wheat'], mealType: ['breakfast', 'lunch', 'dinner'] },
  { id: 'f12', name: 'Aloo Paratha', cuisine: 'north-indian', veg: true, caloriesPer100g: 210, proteinPer100g: 4, carbsPer100g: 28, fatPer100g: 9, allergens: ['Gluten', 'Wheat'], mealType: ['breakfast'] },
  { id: 'f13', name: 'Dal Makhani', cuisine: 'north-indian', veg: true, caloriesPer100g: 115, proteinPer100g: 5, carbsPer100g: 12, fatPer100g: 5, allergens: ['Dairy'], mealType: ['lunch', 'dinner'] },
  { id: 'f14', name: 'Paneer Butter Masala', cuisine: 'north-indian', veg: true, caloriesPer100g: 220, proteinPer100g: 12, carbsPer100g: 8, fatPer100g: 16, allergens: ['Dairy', 'Nuts'], mealType: ['lunch', 'dinner'] },
  { id: 'f15', name: 'Chicken Tikka', cuisine: 'north-indian', veg: false, caloriesPer100g: 148, proteinPer100g: 25, carbsPer100g: 2, fatPer100g: 4, allergens: ['Dairy'], mealType: ['lunch', 'dinner'] },
  { id: 'f16', name: 'Butter Chicken', cuisine: 'north-indian', veg: false, caloriesPer100g: 195, proteinPer100g: 20, carbsPer100g: 6, fatPer100g: 10, allergens: ['Dairy', 'Nuts'], mealType: ['lunch', 'dinner'] },
  { id: 'f17', name: 'Roti/Chapati', cuisine: 'north-indian', veg: true, caloriesPer100g: 120, proteinPer100g: 3.5, carbsPer100g: 25, fatPer100g: 0.5, allergens: ['Gluten', 'Wheat'], mealType: ['lunch', 'dinner'] },
  { id: 'f18', name: 'Chole/Chana Masala', cuisine: 'north-indian', veg: true, caloriesPer100g: 145, proteinPer100g: 8, carbsPer100g: 18, fatPer100g: 4, allergens: ['Chickpea/Legume'], mealType: ['lunch', 'dinner'] },
  { id: 'f19', name: 'Biryani (Veg)', cuisine: 'north-indian', veg: true, caloriesPer100g: 175, proteinPer100g: 4, carbsPer100g: 28, fatPer100g: 5, allergens: ['Nuts', 'Dairy'], mealType: ['lunch', 'dinner'] },
  { id: 'f20', name: 'Biryani (Chicken)', cuisine: 'north-indian', veg: false, caloriesPer100g: 210, proteinPer100g: 12, carbsPer100g: 25, fatPer100g: 7, allergens: ['Nuts', 'Dairy'], mealType: ['lunch', 'dinner'] },
  
  // Snacks & Others
  { id: 'f21', name: 'Poha', cuisine: 'both', veg: true, caloriesPer100g: 110, proteinPer100g: 2.5, carbsPer100g: 20, fatPer100g: 2, allergens: ['Peanut'], mealType: ['breakfast', 'snack'] },
  { id: 'f22', name: 'Sprouts Salad', cuisine: 'both', veg: true, caloriesPer100g: 85, proteinPer100g: 6, carbsPer100g: 12, fatPer100g: 1, allergens: [], mealType: ['breakfast', 'snack'] },
  { id: 'f23', name: 'Boiled Eggs', cuisine: 'other', veg: false, caloriesPer100g: 155, proteinPer100g: 13, carbsPer100g: 1, fatPer100g: 11, allergens: ['Eggs'], mealType: ['breakfast', 'snack'] },
  { id: 'f24', name: 'Oats Porridge', cuisine: 'other', veg: true, caloriesPer100g: 71, proteinPer100g: 2.5, carbsPer100g: 12, fatPer100g: 1.5, allergens: ['Gluten'], mealType: ['breakfast'] },
  { id: 'f25', name: 'Greek Yogurt', cuisine: 'other', veg: true, caloriesPer100g: 97, proteinPer100g: 9, carbsPer100g: 4, fatPer100g: 5, allergens: ['Dairy', 'Lactose'], mealType: ['breakfast', 'snack'] },
  { id: 'f26', name: 'Banana', cuisine: 'other', veg: true, caloriesPer100g: 89, proteinPer100g: 1, carbsPer100g: 23, fatPer100g: 0.3, allergens: [], mealType: ['breakfast', 'snack'] },
  { id: 'f27', name: 'Mixed Nuts (30g)', cuisine: 'other', veg: true, caloriesPer100g: 607, proteinPer100g: 20, carbsPer100g: 17, fatPer100g: 54, allergens: ['Nuts', 'Tree Nuts'], mealType: ['snack'] },
  { id: 'f28', name: 'Whey Protein Shake', cuisine: 'other', veg: true, caloriesPer100g: 380, proteinPer100g: 75, carbsPer100g: 8, fatPer100g: 4, allergens: ['Dairy', 'Soy'], mealType: ['snack'] },
  { id: 'f29', name: 'Steamed Rice', cuisine: 'both', veg: true, caloriesPer100g: 130, proteinPer100g: 2.7, carbsPer100g: 28, fatPer100g: 0.3, allergens: [], mealType: ['lunch', 'dinner'] },
  { id: 'f30', name: 'Grilled Chicken Breast', cuisine: 'other', veg: false, caloriesPer100g: 165, proteinPer100g: 31, carbsPer100g: 0, fatPer100g: 3.6, allergens: [], mealType: ['lunch', 'dinner'] },
];

// Seed Exercises Database
export const SEED_EXERCISES: Exercise[] = [
  // Strength - Beginner
  {
    id: 'e1', name: 'Push-ups', category: 'strength', description: 'Classic upper body exercise targeting chest, shoulders, and triceps.',
    defaultSets: 3, defaultReps: 10, videos: ['https://www.youtube.com/embed/IODxDxX7oi4', 'https://www.youtube.com/embed/_l3ySVKYVJ8'],
    tags: ['chest', 'arms', 'no-equipment'], difficulty: 'beginner', muscleGroups: ['chest', 'shoulders', 'triceps'],
    goalFit: ['muscle gain', 'general health', 'weight loss']
  },
  {
    id: 'e2', name: 'Bodyweight Squats', category: 'strength', description: 'Fundamental lower body exercise for quads, glutes, and hamstrings.',
    defaultSets: 3, defaultReps: 15, videos: ['https://www.youtube.com/embed/aclHkVaku9U'],
    tags: ['legs', 'no-equipment'], difficulty: 'beginner', muscleGroups: ['quads', 'glutes', 'hamstrings'],
    goalFit: ['muscle gain', 'weight loss', 'general health']
  },
  {
    id: 'e3', name: 'Plank', category: 'strength', description: 'Core stability exercise. Hold position for time.',
    defaultSets: 3, defaultReps: 30, duration: 0.5, videos: ['https://www.youtube.com/embed/ASdvN_XEl_c'],
    tags: ['core', 'no-equipment'], difficulty: 'beginner', muscleGroups: ['core', 'abs'],
    goalFit: ['general health', 'muscle gain', 'flexibility']
  },
  {
    id: 'e4', name: 'Lunges', category: 'strength', description: 'Unilateral leg exercise for balance and strength.',
    defaultSets: 3, defaultReps: 12, videos: ['https://www.youtube.com/embed/QOVaHwm-Q6U'],
    tags: ['legs', 'no-equipment'], difficulty: 'beginner', muscleGroups: ['quads', 'glutes'],
    goalFit: ['muscle gain', 'weight loss', 'general health']
  },
  
  // Strength - Intermediate
  {
    id: 'e5', name: 'Diamond Push-ups', category: 'strength', description: 'Advanced push-up variation targeting triceps.',
    defaultSets: 3, defaultReps: 8, videos: ['https://www.youtube.com/embed/J0DnG1_S92I'],
    tags: ['triceps', 'chest', 'no-equipment'], difficulty: 'intermediate', muscleGroups: ['triceps', 'chest'],
    goalFit: ['muscle gain']
  },
  {
    id: 'e6', name: 'Bulgarian Split Squats', category: 'strength', description: 'Single-leg squat with rear foot elevated.',
    defaultSets: 3, defaultReps: 10, videos: ['https://www.youtube.com/embed/2C-uNgKwPLE'],
    tags: ['legs', 'balance'], difficulty: 'intermediate', muscleGroups: ['quads', 'glutes'],
    goalFit: ['muscle gain', 'general health']
  },
  
  // Cardio
  {
    id: 'e7', name: 'Jumping Jacks', category: 'cardio', description: 'Full body cardio exercise to elevate heart rate.',
    defaultSets: 3, defaultReps: 30, duration: 1, videos: ['https://www.youtube.com/embed/c4DAnQ6DtF8'],
    tags: ['cardio', 'no-equipment', 'warmup'], difficulty: 'beginner', muscleGroups: ['full body'],
    goalFit: ['cardio', 'weight loss', 'general health']
  },
  {
    id: 'e8', name: 'Burpees', category: 'cardio', description: 'High-intensity full body exercise.',
    defaultSets: 3, defaultReps: 10, duration: 1, videos: ['https://www.youtube.com/embed/dZgVxmf6jkA'],
    tags: ['cardio', 'hiit', 'no-equipment'], difficulty: 'intermediate', muscleGroups: ['full body'],
    goalFit: ['cardio', 'weight loss']
  },
  {
    id: 'e9', name: 'High Knees', category: 'cardio', description: 'Running in place with high knee lift.',
    defaultSets: 3, defaultReps: 30, duration: 1, videos: ['https://www.youtube.com/embed/D0FZaGYJsKc'],
    tags: ['cardio', 'no-equipment'], difficulty: 'beginner', muscleGroups: ['legs', 'core'],
    goalFit: ['cardio', 'weight loss', 'general health']
  },
  {
    id: 'e10', name: 'Mountain Climbers', category: 'cardio', description: 'Dynamic plank exercise for cardio and core.',
    defaultSets: 3, defaultReps: 20, duration: 1, videos: ['https://www.youtube.com/embed/nmwgirgXLYM'],
    tags: ['cardio', 'core', 'no-equipment'], difficulty: 'intermediate', muscleGroups: ['core', 'shoulders', 'legs'],
    goalFit: ['cardio', 'weight loss', 'general health']
  },
  
  // Flexibility
  {
    id: 'e11', name: 'Standing Hamstring Stretch', category: 'flexibility', description: 'Stretch for posterior leg muscles.',
    defaultSets: 2, defaultReps: 1, duration: 0.5, videos: ['https://www.youtube.com/embed/FDwpEdxZ4H4'],
    tags: ['flexibility', 'legs', 'cooldown'], difficulty: 'beginner', muscleGroups: ['hamstrings'],
    goalFit: ['flexibility', 'general health']
  },
  {
    id: 'e12', name: 'Cat-Cow Stretch', category: 'flexibility', description: 'Spine mobility exercise.',
    defaultSets: 2, defaultReps: 10, videos: ['https://www.youtube.com/embed/kqnua4rHVVA'],
    tags: ['flexibility', 'back', 'warmup'], difficulty: 'beginner', muscleGroups: ['back', 'core'],
    goalFit: ['flexibility', 'general health']
  },
  
  // HIIT
  {
    id: 'e13', name: 'Box Jumps', category: 'hiit', description: 'Explosive plyometric exercise.',
    defaultSets: 3, defaultReps: 8, videos: ['https://www.youtube.com/embed/NBY9-kTuHEk'],
    tags: ['hiit', 'legs', 'power'], difficulty: 'advanced', muscleGroups: ['quads', 'glutes', 'calves'],
    goalFit: ['cardio', 'muscle gain']
  },
  {
    id: 'e14', name: 'Kettlebell Swings', category: 'hiit', description: 'Explosive hip hinge movement.',
    defaultSets: 3, defaultReps: 15, videos: ['https://www.youtube.com/embed/YSxHifyI6s8'],
    tags: ['hiit', 'power', 'full body'], difficulty: 'intermediate', muscleGroups: ['glutes', 'hamstrings', 'core'],
    goalFit: ['cardio', 'muscle gain', 'weight loss']
  },
];

// Generate admin password hash (SHA-256 of "admin123")
// In real app, this would be done server-side
export const ADMIN_PASSWORD_HASH = '240be518fabd2724ddb6f04eeb9d5b8e5a69e7b89ec5f2b9e7f6e2ef42c8f111';

// Seed admin user
export const SEED_ADMIN: Partial<User> = {
  id: 'admin-001',
  email: 'koushikmreddy43@gmail.com',
  passwordHash: ADMIN_PASSWORD_HASH,
  name: 'Admin',
  isAdmin: true,
  onboardingComplete: true,
  settings: {
    theme: 'dark',
    glassMl: 250,
    dailyWaterGoal: 8
  },
  waterLogs: {},
  workoutLogs: [],
  mealOverrides: {},
  createdAt: new Date().toISOString()
};
