// LocalStorage persistence layer for NutriFit

import { User, ChatMessage, PrivateMessage, Feedback, Food, Exercise, SEED_FOODS, SEED_EXERCISES, SEED_ADMIN } from './data';

const KEYS = {
  USERS: 'nutrifit_users',
  FOODS: 'nutrifit_foods',
  EXERCISES: 'nutrifit_exercises',
  CHAT: 'nutrifit_chat',
  PRIVATE_MESSAGES: 'nutrifit_private_messages',
  FEEDBACK: 'nutrifit_feedback',
  SESSION: 'nutrifit_session',
};

// Initialize seed data if not exists
export function initializeData() {
  // Foods
  if (!localStorage.getItem(KEYS.FOODS)) {
    localStorage.setItem(KEYS.FOODS, JSON.stringify(SEED_FOODS));
  }
  
  // Exercises
  if (!localStorage.getItem(KEYS.EXERCISES)) {
    localStorage.setItem(KEYS.EXERCISES, JSON.stringify(SEED_EXERCISES));
  }
  
  // Users (with admin)
  const existingUsers = getUsers();
  const adminExists = existingUsers.some(u => u.email === SEED_ADMIN.email);
  if (!adminExists) {
    const adminUser: User = {
      ...SEED_ADMIN as User,
      age: 30,
      height: 175,
      weight: 70,
      goal: 'general health',
      level: 'advanced',
      diet: 'non-vegetarian',
      cuisine: 'both',
      allergies: [],
    };
    saveUser(adminUser);
  }
  
  // Initialize empty arrays if not exist
  if (!localStorage.getItem(KEYS.CHAT)) {
    localStorage.setItem(KEYS.CHAT, JSON.stringify([]));
  }
  if (!localStorage.getItem(KEYS.PRIVATE_MESSAGES)) {
    localStorage.setItem(KEYS.PRIVATE_MESSAGES, JSON.stringify([]));
  }
  if (!localStorage.getItem(KEYS.FEEDBACK)) {
    localStorage.setItem(KEYS.FEEDBACK, JSON.stringify([]));
  }
}

// Session management
export function setSession(userId: string) {
  localStorage.setItem(KEYS.SESSION, JSON.stringify({ userId, lastActive: Date.now() }));
}

export function getSession(): { userId: string; lastActive: number } | null {
  const session = localStorage.getItem(KEYS.SESSION);
  return session ? JSON.parse(session) : null;
}

export function clearSession() {
  localStorage.removeItem(KEYS.SESSION);
}

// User management
export function getUsers(): User[] {
  const users = localStorage.getItem(KEYS.USERS);
  return users ? JSON.parse(users) : [];
}

export function getUserById(id: string): User | null {
  const users = getUsers();
  return users.find(u => u.id === id) || null;
}

export function getUserByEmail(email: string): User | null {
  const users = getUsers();
  return users.find(u => u.email.toLowerCase() === email.toLowerCase()) || null;
}

export function saveUser(user: User) {
  const users = getUsers();
  const index = users.findIndex(u => u.id === user.id);
  if (index >= 0) {
    users[index] = user;
  } else {
    users.push(user);
  }
  localStorage.setItem(KEYS.USERS, JSON.stringify(users));
}

export function deleteUser(userId: string) {
  const users = getUsers().filter(u => u.id !== userId);
  localStorage.setItem(KEYS.USERS, JSON.stringify(users));
}

// Password hashing using SubtleCrypto
export async function hashPassword(password: string): Promise<string> {
  try {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  } catch {
    // Fallback - in production, never store plain text
    console.warn('SHA-256 not available. Using fallback (not secure for production).');
    return btoa(password);
  }
}

// Foods management
export function getFoods(): Food[] {
  const foods = localStorage.getItem(KEYS.FOODS);
  return foods ? JSON.parse(foods) : SEED_FOODS;
}

export function saveFood(food: Food) {
  const foods = getFoods();
  const index = foods.findIndex(f => f.id === food.id);
  if (index >= 0) {
    foods[index] = food;
  } else {
    foods.push(food);
  }
  localStorage.setItem(KEYS.FOODS, JSON.stringify(foods));
}

export function deleteFood(foodId: string) {
  const foods = getFoods().filter(f => f.id !== foodId);
  localStorage.setItem(KEYS.FOODS, JSON.stringify(foods));
}

// Exercises management
export function getExercises(): Exercise[] {
  const exercises = localStorage.getItem(KEYS.EXERCISES);
  return exercises ? JSON.parse(exercises) : SEED_EXERCISES;
}

export function saveExercise(exercise: Exercise) {
  const exercises = getExercises();
  const index = exercises.findIndex(e => e.id === exercise.id);
  if (index >= 0) {
    exercises[index] = exercise;
  } else {
    exercises.push(exercise);
  }
  localStorage.setItem(KEYS.EXERCISES, JSON.stringify(exercises));
}

export function deleteExercise(exerciseId: string) {
  const exercises = getExercises().filter(e => e.id !== exerciseId);
  localStorage.setItem(KEYS.EXERCISES, JSON.stringify(exercises));
}

// Chat messages
export function getChatMessages(): ChatMessage[] {
  const messages = localStorage.getItem(KEYS.CHAT);
  return messages ? JSON.parse(messages) : [];
}

export function saveChatMessage(message: ChatMessage) {
  const messages = getChatMessages();
  const index = messages.findIndex(m => m.id === message.id);
  if (index >= 0) {
    messages[index] = message;
  } else {
    messages.push(message);
  }
  localStorage.setItem(KEYS.CHAT, JSON.stringify(messages));
}

export function deleteChatMessage(messageId: string) {
  const messages = getChatMessages().filter(m => m.id !== messageId);
  localStorage.setItem(KEYS.CHAT, JSON.stringify(messages));
}

// Private messages
export function getPrivateMessages(): PrivateMessage[] {
  const messages = localStorage.getItem(KEYS.PRIVATE_MESSAGES);
  return messages ? JSON.parse(messages) : [];
}

export function savePrivateMessage(message: PrivateMessage) {
  const messages = getPrivateMessages();
  messages.push(message);
  localStorage.setItem(KEYS.PRIVATE_MESSAGES, JSON.stringify(messages));
}

export function markMessageAsRead(messageId: string) {
  const messages = getPrivateMessages();
  const index = messages.findIndex(m => m.id === messageId);
  if (index >= 0) {
    messages[index].read = true;
    localStorage.setItem(KEYS.PRIVATE_MESSAGES, JSON.stringify(messages));
  }
}

// Feedback
export function getFeedback(): Feedback[] {
  const feedback = localStorage.getItem(KEYS.FEEDBACK);
  return feedback ? JSON.parse(feedback) : [];
}

export function saveFeedback(feedback: Feedback) {
  const feedbacks = getFeedback();
  const index = feedbacks.findIndex(f => f.id === feedback.id);
  if (index >= 0) {
    feedbacks[index] = feedback;
  } else {
    feedbacks.push(feedback);
  }
  localStorage.setItem(KEYS.FEEDBACK, JSON.stringify(feedbacks));
}

// Export/Import data
export function exportUserData(userId: string): string {
  const user = getUserById(userId);
  if (!user) return '';
  
  const privateMessages = getPrivateMessages().filter(
    m => m.fromUserId === userId || m.toUserId === userId
  );
  
  const exportData = {
    user,
    privateMessages,
    exportedAt: new Date().toISOString()
  };
  
  return JSON.stringify(exportData, null, 2);
}

export function importUserData(userId: string, jsonData: string): boolean {
  try {
    const data = JSON.parse(jsonData);
    if (data.user && data.user.id === userId) {
      saveUser(data.user);
      return true;
    }
    return false;
  } catch {
    return false;
  }
}

// Export all data (admin)
export function exportAllData(): string {
  return JSON.stringify({
    users: getUsers(),
    foods: getFoods(),
    exercises: getExercises(),
    chat: getChatMessages(),
    privateMessages: getPrivateMessages(),
    feedback: getFeedback(),
    exportedAt: new Date().toISOString()
  }, null, 2);
}

export function importAllData(jsonData: string): boolean {
  try {
    const data = JSON.parse(jsonData);
    if (data.users) localStorage.setItem(KEYS.USERS, JSON.stringify(data.users));
    if (data.foods) localStorage.setItem(KEYS.FOODS, JSON.stringify(data.foods));
    if (data.exercises) localStorage.setItem(KEYS.EXERCISES, JSON.stringify(data.exercises));
    if (data.chat) localStorage.setItem(KEYS.CHAT, JSON.stringify(data.chat));
    if (data.privateMessages) localStorage.setItem(KEYS.PRIVATE_MESSAGES, JSON.stringify(data.privateMessages));
    if (data.feedback) localStorage.setItem(KEYS.FEEDBACK, JSON.stringify(data.feedback));
    return true;
  } catch {
    return false;
  }
}
