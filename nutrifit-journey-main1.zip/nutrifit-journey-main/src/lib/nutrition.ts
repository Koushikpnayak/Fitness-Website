// Nutrition calculation engine for NutriFit

import { User, Food } from './data';
import { getFoods } from './storage';

export interface MealPlanItem {
  food: Food;
  grams: number;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  mealType: string;
  replaced?: boolean;
  replacementReason?: string;
}

export interface DailyMealPlan {
  date: string;
  targetCalories: number;
  targetProtein: number;
  meals: {
    breakfast: MealPlanItem[];
    lunch: MealPlanItem[];
    dinner: MealPlanItem[];
    snacks: MealPlanItem[];
  };
  totals: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  };
}

// Calculate daily calorie needs based on user profile
export function calculateDailyCalories(user: User): number {
  // Harris-Benedict BMR formula
  let bmr: number;
  const isMale = true; // Default assumption, could add gender to profile
  
  if (isMale) {
    bmr = 88.362 + (13.397 * user.weight) + (4.799 * user.height) - (5.677 * user.age);
  } else {
    bmr = 447.593 + (9.247 * user.weight) + (3.098 * user.height) - (4.330 * user.age);
  }
  
  // Activity multiplier
  const activityMultipliers: Record<string, number> = {
    'sedentary': 1.2,
    'moderate': 1.55,
    'active': 1.725,
  };
  
  const activityLevel = user.activityLevel || 'moderate';
  const tdee = bmr * (activityMultipliers[activityLevel] || 1.55);
  
  // Goal adjustment
  const goalAdjustments: Record<string, number> = {
    'weight loss': -500,
    'weight gain': +500,
    'muscle gain': +300,
    'cardio': -200,
    'flexibility': 0,
    'general health': 0,
  };
  
  let dailyCalories = tdee + (goalAdjustments[user.goal] || 0);
  
  // Ensure minimum safe calories
  dailyCalories = Math.max(dailyCalories, 1200);
  
  return Math.round(dailyCalories);
}

// Calculate daily protein needs
export function calculateDailyProtein(user: User): number {
  const proteinPerKg: Record<string, number> = {
    'weight loss': 1.0,
    'weight gain': 1.2,
    'muscle gain': 1.4,
    'cardio': 1.0,
    'flexibility': 0.8,
    'general health': 0.8,
  };
  
  let baseProtein = user.weight * (proteinPerKg[user.goal] || 1.2);
  
  // Adjust by experience level
  if (user.level === 'advanced' && user.goal === 'muscle gain') {
    baseProtein *= 1.1;
  }
  
  return Math.round(baseProtein);
}

// Filter foods based on user preferences and allergies
export function filterFoodsForUser(user: User, foods: Food[]): Food[] {
  return foods.filter(food => {
    // Diet filter
    if (user.diet === 'vegetarian' && !food.veg) {
      return false;
    }
    
    // Cuisine filter
    if (user.cuisine !== 'both' && user.cuisine !== 'other') {
      if (food.cuisine !== user.cuisine && food.cuisine !== 'both' && food.cuisine !== 'other') {
        return false;
      }
    }
    
    // Allergy filter
    if (user.allergies && user.allergies.length > 0) {
      const hasAllergen = food.allergens.some(allergen => 
        user.allergies.some(userAllergen => 
          allergen.toLowerCase().includes(userAllergen.toLowerCase()) ||
          userAllergen.toLowerCase().includes(allergen.toLowerCase())
        )
      );
      if (hasAllergen) {
        return false;
      }
    }
    
    return true;
  });
}

// Find replacement food for one with allergens
export function findReplacement(
  excludeFood: Food,
  mealType: string,
  availableFoods: Food[],
  usedFoodIds: Set<string>
): Food | null {
  const candidates = availableFoods.filter(f => 
    f.id !== excludeFood.id &&
    !usedFoodIds.has(f.id) &&
    f.mealType.includes(mealType as any) &&
    Math.abs(f.caloriesPer100g - excludeFood.caloriesPer100g) < 50 // Similar calorie density
  );
  
  if (candidates.length === 0) return null;
  
  // Prefer similar protein content
  candidates.sort((a, b) => 
    Math.abs(a.proteinPer100g - excludeFood.proteinPer100g) - 
    Math.abs(b.proteinPer100g - excludeFood.proteinPer100g)
  );
  
  return candidates[0];
}

// Generate daily meal plan
export function generateMealPlan(user: User): DailyMealPlan {
  const allFoods = getFoods();
  const safeFoods = filterFoodsForUser(user, allFoods);
  
  const targetCalories = calculateDailyCalories(user);
  const targetProtein = calculateDailyProtein(user);
  
  // Distribution: 25% breakfast, 35% lunch, 30% dinner, 10% snacks
  const distribution = {
    breakfast: 0.25,
    lunch: 0.35,
    dinner: 0.30,
    snacks: 0.10,
  };
  
  const meals: DailyMealPlan['meals'] = {
    breakfast: [],
    lunch: [],
    dinner: [],
    snacks: [],
  };
  
  const usedFoodIds = new Set<string>();
  const totals = { calories: 0, protein: 0, carbs: 0, fat: 0 };
  
  // Generate meals for each type
  (Object.keys(distribution) as Array<keyof typeof distribution>).forEach(mealType => {
    const mealCalorieTarget = targetCalories * distribution[mealType];
    let mealCalories = 0;
    
    // Get foods suitable for this meal type
    let mealFoods = safeFoods.filter(f => f.mealType.includes(mealType as any));
    
    // If no foods available, use all safe foods
    if (mealFoods.length === 0) {
      mealFoods = safeFoods;
    }
    
    // Select 2-3 items per meal (1 for snacks)
    const itemCount = mealType === 'snacks' ? 1 : Math.min(3, mealFoods.length);
    
    for (let i = 0; i < itemCount && mealCalories < mealCalorieTarget; i++) {
      // Find unused food
      const available = mealFoods.filter(f => !usedFoodIds.has(f.id));
      if (available.length === 0) break;
      
      // Prioritize high protein for muscle gain goals
      if (user.goal === 'muscle gain') {
        available.sort((a, b) => b.proteinPer100g - a.proteinPer100g);
      }
      
      const food = available[i % available.length];
      usedFoodIds.add(food.id);
      
      // Calculate portion to meet calorie target
      const remainingCalories = mealCalorieTarget - mealCalories;
      let grams = Math.round((remainingCalories / food.caloriesPer100g) * 100);
      
      // Reasonable portion limits
      grams = Math.max(50, Math.min(grams, 300));
      
      const calories = Math.round((grams / 100) * food.caloriesPer100g);
      const protein = Math.round((grams / 100) * food.proteinPer100g * 10) / 10;
      const carbs = Math.round((grams / 100) * food.carbsPer100g * 10) / 10;
      const fat = Math.round((grams / 100) * food.fatPer100g * 10) / 10;
      
      const mealItem: MealPlanItem = {
        food,
        grams,
        calories,
        protein,
        carbs,
        fat,
        mealType,
      };
      
      // Check if this food has allergens for user (shouldn't happen if filtered, but double-check)
      const hasAllergen = user.allergies?.some(allergen => 
        food.allergens.some(fa => fa.toLowerCase().includes(allergen.toLowerCase()))
      );
      
      if (hasAllergen) {
        const replacement = findReplacement(food, mealType, allFoods, usedFoodIds);
        if (replacement) {
          mealItem.food = replacement;
          mealItem.replaced = true;
          mealItem.replacementReason = `Replaced ${food.name} due to allergy`;
          mealItem.calories = Math.round((grams / 100) * replacement.caloriesPer100g);
          mealItem.protein = Math.round((grams / 100) * replacement.proteinPer100g * 10) / 10;
        }
      }
      
      meals[mealType].push(mealItem);
      mealCalories += mealItem.calories;
      totals.calories += mealItem.calories;
      totals.protein += mealItem.protein;
      totals.carbs += mealItem.carbs;
      totals.fat += mealItem.fat;
    }
  });
  
  return {
    date: new Date().toISOString().split('T')[0],
    targetCalories,
    targetProtein,
    meals,
    totals: {
      calories: Math.round(totals.calories),
      protein: Math.round(totals.protein),
      carbs: Math.round(totals.carbs),
      fat: Math.round(totals.fat),
    },
  };
}

// Recalculate meal item based on new grams
export function recalculateMealItem(item: MealPlanItem, newGrams: number): MealPlanItem {
  return {
    ...item,
    grams: newGrams,
    calories: Math.round((newGrams / 100) * item.food.caloriesPer100g),
    protein: Math.round((newGrams / 100) * item.food.proteinPer100g * 10) / 10,
    carbs: Math.round((newGrams / 100) * item.food.carbsPer100g * 10) / 10,
    fat: Math.round((newGrams / 100) * item.food.fatPer100g * 10) / 10,
  };
}
