import { useAuth } from '@/contexts/AuthContext';
import { AuthPage } from '@/components/AuthPage';
import { OnboardingPage } from '@/components/OnboardingPage';
import { MainApp } from '@/components/MainApp';
import { LoadingSpinner } from '@/components/LoadingSpinner';

const Index = () => {
  const { user, loading } = useAuth();

  if (loading) {
    return <LoadingSpinner fullScreen text="Loading NutriFit..." />;
  }

  // Not logged in - show auth
  if (!user) {
    return <AuthPage />;
  }

  // Logged in but onboarding incomplete
  if (!user.onboardingComplete) {
    return <OnboardingPage />;
  }

  // Fully authenticated
  return <MainApp />;
};

export default Index;
